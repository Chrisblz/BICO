import React from 'react';
import Datas from '../../data/faq/question.json';
import AccordionItem from './../../components/faq/AccordionItem';
import { Styles } from "../../components/faq/styles/accordion.js";

class QuestionItem extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Question Area */}
                <div className="accordion-box">
                    {
                        this.state.Data.map((data, i) => (
                            <AccordionItem
                                title={data.title}
                                body={data.body}
                                key={i}
                            />
                        ))
                    }
                </div>
            </Styles>
        )
    }
}

export default QuestionItem