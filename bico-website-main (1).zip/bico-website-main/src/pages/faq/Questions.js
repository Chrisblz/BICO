import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import QuestionItem from './QuestionItems';
import ServiceForm from './../service/components/ServiceForm';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/questions.js";

const Question = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper question-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Faq" />

                {/* Questions Area */}
                <section className="questions-area">
                    <Container>
                        <Row>
                            <Col xl="9" md="8">
                                <div className="question-box">
                                    <QuestionItem />
                                </div>
                            </Col>
                            <Col xl="3" md="4">
                                <ServiceForm />
                                <div className="banner">
                                    <a href="/"><img src={process.env.PUBLIC_URL + `/assets/images/banner.jpg`} className="img-fluid" alt="" /></a>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default Question