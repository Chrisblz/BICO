import styled from "styled-components";
import { colors } from './../../../components/common/element/elements.js';

export const Styles = styled.div`
    .service-form {
        background: ${colors.black1};
        padding: 20px 25px 25px;
        border-radius: 15px;
        margin-bottom: 30px;
        h6 {
            color: ${colors.border1};
            margin-bottom: 20px;
            position: relative;
            &:before {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -10px;
                left: 0;
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -8px;
                left: 0;
            }
        }
        
        form.service_form {
            p.form-box {
                padding   : 0;
                width     : auto;
                height    : auto;
                background: transparent;
                border    : none;
                margin-bottom: 20px;
                position  : relative;

                input {
                    width           : 100%;
                    height          : 38px;
                    background-color: transparent;
                    font-size       : 14px;
                    padding         : 15px 0;
                    color           : #ffffff;
                    border          : none;
                    border-radius : 0;
                    border-bottom : 1px solid ${colors.text2};

                    &:focus {
                        border-color: ${colors.blue};
                        box-shadow: none;
                    }

                    &::placeholder {
                        font-size  : 14px;
                        color      : ${colors.border1};
                        font-weight : 300;
                    }
                }

                textarea {
                    width           : 100%;
                    height          : 95px;
                    background-color: transparent;
                    font-size       : 14px;
                    padding         : 10px 0;
                    color           : #ffffff;
                    border          : none;
                    border-radius : 0;
                    border-bottom : 1px solid ${colors.text2};

                    &:focus {
                        border-color: ${colors.blue};
                        box-shadow: none;
                    }

                    &::placeholder {
                        font-size  : 14px;
                        color      : ${colors.border1};
                        font-weight : 300;
                    }
                }

                label.error {
                    font-size: 13px;
                    color: ${colors.red};
                    position: absolute;
                    top: 100%;
                    left: 0;
                    font-weight: 300;
                    line-height: 14px;
                    letter-spacing: 0;
                }
            }

            button {
                color: #fff;
                background-color: ${colors.red};
                font-size: 15px;
                font-weight: 500;
                border : none;
                border-radius: 0 20px 0;
                width: 100%;
                height: 36px;
                margin-top: 8px;
                &:hover {
                    background: ${colors.blue};
                }
            }
        }
    }
`;