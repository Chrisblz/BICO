import styled from "styled-components";
import { colors } from './../../../components/common/element/elements.js';

export const Styles = styled.div`
    /* Recent Blog */
    .recent-blog {
        border : 1px solid ${colors.border3};
        padding: 18px 18px 20px;
        border-radius : 15px;
        h6 {
            color : ${colors.black1};
            margin-bottom: 32px;
            position: relative;
            &:before {
                position: absolute;
                content: "";  
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -10px;
                left: 0;
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -8px;
                left: 0;
            }
        }

        .blog-items {
            .item-box {
                margin-bottom: 15px;
                .item-img {
                    a {
                        img {
                            max-width: 75px;
                            border-radius: 5px;
                            margin-right: 12px;
                        }
                    }
                }

                .item-content {
                    padding-top: 5px;
                    p.title {
                        margin-top: 5px;
                        a {
                            color: ${colors.black2};
                            font-weight: 500;
                            &:hover {
                                color : ${colors.blue};
                            }
                        }
                    }

                    span.date {
                        font-size : 12px;
                        color : ${colors.text3};
                    }
                }

                &:last-child {
                    margin-bottom: 0;
                }
            }
        }

        @media only screen and (max-width: 767px) {
            margin-bottom: 30px;
        }
    }
`;