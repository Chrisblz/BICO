import styled from "styled-components";
import { colors } from './../../../components/common/element/elements.js';

export const Styles = styled.div`
    .service-details {
        .service-details-area {
            padding: 70px 0 48px;
            .service-sidebar {
                .service-category {
                    border: 1px solid ${colors.border3};
                    padding: 18px;
                    border-radius: 15px;
                    margin-bottom: 30px;
                    ul {
                        li {
                            a {
                                display: block;
                                background: ${colors.bg1};
                                color: ${colors.black1};
                                font-size: 14px;
                                font-weight: 500;
                                padding: 10px 18px;
                                border-radius: 8px;
                                margin-bottom: 12px;
                                &:hover {
                                    background: ${colors.red};
                                    color: #ffffff;
                                }
                            }
                            &:last-child {
                                a {
                                    margin-bottom: 0;
                                }
                            }
                        }
                        li.active {
                            a {
                                background: ${colors.red};
                                color: #ffffff;
                            }
                        }
                    }
                }
            }

            .service-details-box {
                .service-banner {
                    img {
                        border-radius: 20px;
                        margin-bottom: 25px;
                    }
                    h5 {
                        color: ${colors.black1};
                        font-weight: 700;
                        margin-bottom: 15px;
                    }
                    p {
                        font-size: 15px;
                        color: ${colors.text2};
                        line-height: 27px;
                        margin-bottom: 25px;
                    }
                    span {
                        font-size: 14px;
                        color: ${colors.text1};
                        line-height: 27px;
                        background: ${colors.bg2};
                        display: block;
                        border-left: 3px solid ${colors.blue};
                        padding: 20px 25px;
                        border-radius: 15px;
                        margin-bottom: 32px;
                    }
                }

                .service-overview {
                    margin-bottom: 40px;
                    .overview-img {
                        img {
                            border-radius: 20px;

                            @media only screen and (max-width: 767px) {
                                margin-bottom: 20px;
                            }
                        }
                    }
                    .overview-content {
                        h5 {
                            color: ${colors.black1};
                            font-weight: 700;
                            margin-bottom: 15px;
                        }
                        p {
                            font-size: 14px;
                            color: ${colors.text1};
                            line-height: 27px;
                            margin-bottom: 15px;
                        }
                        span {
                            font-size: 16px;
                            color: ${colors.red};
                            font-weight: 600;
                            display: block;
                            margin-bottom: 25px;
                            line-height: 25px;
                        }
                        ul {
                            li {
                                font-size: 14px;
                                color: ${colors.text2};
                                line-height: 25px;
                                margin-bottom: 10px;
                                i {
                                    font-size: 24px;
                                    color: ${colors.blue};
                                    margin-right: 8px;
                                    float: left;
                                    height: 35px;
                                    transform: translateY(8%);
                                }

                                &:last-child {
                                    margin-bottom: 0;
                                }
                            }
                        }
                    }
                }

                .service-tab {
                    .nav {
                        margin-bottom: 40px;
                        .nav-item {
                            margin-right: 15px;
                            a.nav-link {
                                font-size    : 15px;
                                color        : ${colors.black1};
                                background: ${colors.bg2};
                                padding      : 12px 25px;
                                border-radius: 0 25px;
                                font-weight: 500;
                                text-transform: uppercase;

                                @media only screen and (max-width: 575px) {
                                    font-size    : 14px;
                                    padding: 10px 18px;
                                }
                            }

                            a.nav-link.active {
                                background: ${colors.red};
                                color     : #ffffff;

                                i {
                                    color: #ffffff;
                                }
                            }

                            &:last-child {
                                a.nav-link {
                                    border-bottom: none;
                                }
                            }
                        }
                    }

                    .tab-content {
                        .tab-pane {
                            .question-tab {
                                .question-item {
                                    margin-bottom: 20px;
                                    .qc-title {
                                        p {
                                            font-size: 16px;
                                            color: ${colors.black2};
                                            font-weight: 500;
                                            margin-bottom: 10px;
                                            span {
                                                font-size: 14px;
                                                color: #ffffff;
                                                background: ${colors.blue};
                                                padding: 5px 10px;
                                                border-radius: 0 12px;
                                                margin-right: 5px;
                                            }

                                            @media only screen and (max-width: 575px) {
                                                font-size    : 15px;
                                            }
                                        }
                                    }
                                    .qc-desc {
                                        p {
                                            font-size: 14px;
                                            color: ${colors.text2};
                                            line-height: 23px;
                                            padding-left: 40px;
                                        }
                                    }
                                }
                            }

                            .review-tab, .member-tab {
                                p {
                                    font-size: 14px;
                                    color: ${colors.text2};
                                    line-height: 27px;
                                }
                            }
                        }
                    }
                }
            }

            @media only screen and (max-width: 575px) {
                padding: 40px 0 9px;
            }
        }
    }
`;