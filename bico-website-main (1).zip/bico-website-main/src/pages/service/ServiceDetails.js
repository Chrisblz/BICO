import React from 'react';
import { Container, Row, Col, Tab, Nav } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ServiceForm from './components/ServiceForm';
import RecentPost from './components/RecentPost';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/serviceDetails.js";

const ServiceDetails = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper service-details">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Service Details" />

                {/* Service Details */}
                <section className="service-details-area">
                    <Container>
                        <Row>
                            <Col xl="3" md="4">
                                <div className="service-sidebar">
                                    <Row>
                                        <Col md="12">
                                            <div className="service-category">
                                                <ul className="list-unstyled">
                                                    <li className="active"><a href="/">House Cleaning</a></li>
                                                    <li><a href="/">Office Cleaning</a></li>
                                                    <li><a href="/">Carpet Cleaning</a></li>
                                                    <li><a href="/">Window Cleaning</a></li>
                                                    <li><a href="/">Indoor Cleaning</a></li>
                                                    <li><a href="/">Outndoor Cleaning</a></li>
                                                    <li><a href="/">Bathroom Cleaning</a></li>
                                                </ul>
                                            </div>
                                        </Col>
                                        <Col md="12">
                                            <ServiceForm />
                                        </Col>
                                        <Col md="12">
                                            <RecentPost />
                                        </Col>
                                    </Row>
                                </div>
                            </Col>

                            <Col xl="9" md="8">
                                <div className="service-details-box">
                                    <div className="service-banner">
                                        <img src={process.env.PUBLIC_URL + `/assets/images/service-dtls.jpg`} alt="" className="img-fluid" />
                                        <h5>Office Cleaning Service That We Provide</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus, magni commodi adipisci reiciendis do recusandae amet pariatur magnam perspiciatis fugit tempore quae, onsectetur adipisicing elit. Cupidita neque harum et placeat at sapiente hic, dolores nam molestias ea dolorem ipsa illo corporis, labore nihil omnis. odit atque quasi ipsa, sint doloribus seco.</p>
                                        <span>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non harum a voluptate, dicta numquam fugit mollitia tempore officia maxime, quos at blanditiis in fuga dolor reiciendis do recusandae amet pariatur suscipit iure, rerum cupiditate culpa.</span>
                                    </div>
                                    <div className="service-overview">
                                        <Row>
                                            <Col md="5">
                                                <div className="overview-img">
                                                    <img src={process.env.PUBLIC_URL + `/assets/images/blog-1.jpg`} alt="" className="img-fluid" />
                                                </div>
                                            </Col>
                                            <Col md="7">
                                                <div className="overview-content">
                                                    <h5>Service Overview</h5>
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem totam alias eius doloribus, itaque blanditiis tenetur velit sokam magni commodi adipisci reiciendis do recusandae dishek mera ratione onim eaque.</p>
                                                    <span>Perferendi amet accusamus ratione solim calasu kasm key maxime quaerat.</span>
                                                    <ul className="icon-box list-unstyled">
                                                        <li>
                                                            <i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet onsectetur adipisicing consect minixe dimare tana.
                                                        </li>
                                                        <li>
                                                            <i className="las la-check-circle"></i>Obcaecati makam  labore nihil kisim maxime lopu namkinse vitae tempora.
                                                        </li>
                                                        <li>
                                                            <i className="las la-check-circle"></i>Quidem totam quas rerum cupiditate culpa consec nostrm sapan iksim ipsa soqu.
                                                        </li>
                                                    </ul>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>

                                    <div className="service-tab">
                                        <Tab.Container defaultActiveKey="question">
                                            <Nav>
                                                <Nav.Item>
                                                    <Nav.Link eventKey="question">Questions</Nav.Link>
                                                </Nav.Item>
                                                <Nav.Item>
                                                    <Nav.Link eventKey="review">Reviews</Nav.Link>
                                                </Nav.Item>
                                                <Nav.Item>
                                                    <Nav.Link eventKey="member">Members</Nav.Link>
                                                </Nav.Item>
                                            </Nav>
                                            <Tab.Content>
                                                <Tab.Pane eventKey="question">
                                                    <div className="question-tab">
                                                        <Row>
                                                            <Col md="6">
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                            </Col>
                                                            <Col md="6">
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                                <div className="question-item">
                                                                    <div className="qc-title d-flex">
                                                                        <p><span>Q</span> I don't know What should I write here?</p>
                                                                    </div>
                                                                    <div className="qc-desc">
                                                                        <p>Anim pariatur cliche reprehenderit, enim eiusm high life accusamus terry ad squid.</p>
                                                                    </div>
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </Tab.Pane>
                                                <Tab.Pane eventKey="review">
                                                    <div className="review-tab">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum sed, modi, unde eveniet magni quod velit excepturi Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quasi iste recusandae, soluta nam inventore illo a fugiat laudantium vel quisquam placeat eum magni delectus atque nisi, in necessitatibus dignissimos. id earum veritatis esse commodi! Odio sed iusto architecto harum est reiciendis aut.</p>
                                                    </div>
                                                </Tab.Pane>
                                                <Tab.Pane eventKey="member">
                                                    <div className="member-tab">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum sed, modi, unde eveniet magni quod velit excepturi Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quasi iste recusandae, soluta nam inventore illo a fugiat laudantium vel quisquam placeat eum magni delectus atque nisi, in necessitatibus dignissimos. id earum veritatis esse commodi! Odio sed iusto architecto harum est reiciendis aut.</p>
                                                    </div>
                                                </Tab.Pane>
                                            </Tab.Content>
                                        </Tab.Container>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ServiceDetails