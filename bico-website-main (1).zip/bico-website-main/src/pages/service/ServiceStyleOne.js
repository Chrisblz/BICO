import React from 'react';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import Service from '../../components/service/Service';
import Banner from '../../components/banner/Banner';
import TeamSlider from '../../components/team/TeamSlider';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/serviceStyleOne.js";

const ServiceStyleOne = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper service-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Our Services" />

                {/* Service Area */}
                <Service />

                {/* Banner Area */}
                <Banner />

                {/* Team Area */}
                <TeamSlider />

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ServiceStyleOne