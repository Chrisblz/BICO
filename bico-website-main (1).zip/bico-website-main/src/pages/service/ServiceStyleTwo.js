import React from 'react';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ServiceTwo from '../../components/service/ServiceTwo';
import Banner from '../../components/banner/Banner';
import TeamSlider from '../../components/team/TeamSlider';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/serviceStyleTwo.js";

const ServiceStyleTwo = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper service2-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Our Services" />

                {/* Service Area */}
                <ServiceTwo />

                {/* Banner Area */}
                <Banner />

                {/* Team Area */}
                <TeamSlider />

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ServiceStyleTwo