import React from 'react';
import ReactFormValidation from "react-form-input-validation";
import { Styles } from '../styles/serviceForm.js';

class ServiceForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: {
                full_name: "",
                email: "",
                phone: "",
                message: ""
            },
            errors: {}
        };

        this.form = new ReactFormValidation(this, { locale: "en" });

        this.form.useRules({
            full_name: "required",
            email: "required|email",
            phone: "required|numeric",
            message: "required|max:200"
        });
    }

    render() {
        return (
            <Styles>
                {/* Service Form */}
                <div className="service-form">
                    <h6>Consult with expert</h6>
                    <form className="service_form" noValidate autoComplete="off" onSubmit={this.form.handleSubmit}>
                        <p className="form-box">
                            <input
                                type="text"
                                name="full_name"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.full_name}
                                placeholder="First Name"
                                data-attribute-name="First Name"
                                data-async
                            />
                            <label className="error">{this.state.errors.full_name ? this.state.errors.full_name : ""}</label>
                        </p>
                        <p className="form-box">
                            <input
                                type="text"
                                name="email"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.email}
                                placeholder="Email Address"
                                data-attribute-name="Email Address"
                                data-async
                            />
                            <label className="error">{this.state.errors.email ? this.state.errors.email : ""}</label>
                        </p>
                        <p className="form-box">
                            <input
                                type="text"
                                name="phone"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.phone}
                                placeholder="Phone Number"
                            />
                            <label className="error">{this.state.errors.phone ? this.state.errors.phone : ""}</label>
                        </p>
                        <p className="form-box">
                            <textarea
                                name="message"
                                maxLength="200"
                                className="form-control"
                                value={this.state.fields.message}
                                onChange={this.form.handleChangeEvent}
                                onBlur={this.form.handleBlurEvent}
                                placeholder="Message"
                            ></textarea>
                            <label className="error">{this.state.errors.message ? this.state.errors.message : ""}</label>
                        </p>
                        <button type="submit">Send Message</button>
                    </form>
                </div>
            </Styles >
        )
    }
}

export default ServiceForm