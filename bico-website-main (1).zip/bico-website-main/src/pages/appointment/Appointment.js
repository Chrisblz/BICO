import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ModalForm from '../../components/common/ModalForm';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/appointment.js";

const Appointment = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper appointment-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Appointment" />

                {/* Appointment Area */}
                <section className="appointment-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <div className="appointment-box text-center">
                                    <h3>Book an Appointment</h3>
                                    <ModalForm />
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default Appointment