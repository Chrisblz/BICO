import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .appointment-page {
        .appointment-area {
            padding: 70px 0;
            .appointment-box {
                padding: 30px 35px 35px;
                max-width: 550px;
                border-radius: 25px;
                box-shadow: rgb(0 0 0 / 10%) 0px 8px 20px;
                margin: auto;

                h3 {
                    color: ${colors.black1};
                    font-weight: 700;
                    margin-bottom: 40px;
                    position: relative;
                    &:before {
                        position: absolute;
                        content: "";
                        background: ${colors.blue};
                        width: 60px;
                        height: 1px;
                        bottom: -15px;
                        left: 50%;
                        margin-left: -30px;
                    }
                    &:after {
                        position: absolute;
                        content: "";
                        background: ${colors.blue};
                        width: 60px;
                        height: 1px;
                        bottom: -13px;
                        left: 50%;
                        margin-left: -30px;
                    }
                }

                form.appointment-form {
                    p.form-box {
                        padding   : 0;
                        width     : auto;
                        height    : auto;
                        background: transparent;
                        border    : none;
                        margin-bottom : 30px;
                        position  : relative;

                        input.form-control {
                            width           : 100%;
                            height          : 50px;
                            background      : transparent;
                            border          : 1px solid ${colors.border3};
                            font-size       : 15px;
                            padding         : 15px 20px;
                            color           : ${colors.text2};
                            border-radius   : 17px;

                            &:focus {
                                border-color: ${colors.blue};
                                outline: none;
                                box-shadow: none;
                            }

                            &::placeholder {
                                font-size  : 14px;
                                color      : ${colors.text2};
                            }

                            @media only screen and (max-width: 575px) {
                                height: 42px;
                                border-radius: 15px;
                                padding: 0px 15px;
                            }
                        }

                        label.error {
                            font-size: 14px;
                            color      : ${colors.red};
                            position   : absolute;
                            top        : 100%;
                            left       : 0;
                            text-align: left;
                            line-height: 18px;
                            letter-spacing: 0;
                        }

                        select.form-control {
                            width           : 100%;
                            height          : 50px;
                            background      : transparent;
                            border          : 1px solid ${colors.border3};
                            font-size       : 15px;
                            padding         : 13px 15px;
                            color           : ${colors.text2};
                            border-radius   : 17px;
                            &:focus {
                                box-shadow : none;
                                border-color: ${colors.blue};
                            }

                            @media only screen and (max-width: 575px) {
                                height: 42px;
                                border-radius: 15px;
                                padding: 0px 15px;
                            }
                        }

                        textarea {
                            width           : 100%;
                            height          : 160px;
                            background      : transparent;
                            border          : 1px solid ${colors.border3};
                            font-size       : 14px;
                            padding         : 15px 20px;
                            color           : ${colors.black2};
                            border-radius   : 17px;

                            &:focus {
                                border-color: ${colors.blue};
                                box-shadow : none;
                                outline: none;
                            }

                            &::placeholder {
                                font-size  : 14px;
                                color      : ${colors.text2};
                            }

                            @media only screen and (max-width: 575px) {
                                padding: 10px 15px;
                                height: 110px;
                            }
                        }

                        @media only screen and (max-width: 575px) {
                            margin-bottom: 25px;
                        }
                    }

                    button {
                        font-size : 16px;
                        color     : #fff;
                        background: ${colors.blue};
                        width     : 100%;
                        height    : 50px;
                        border    : none;
                        font-weight: 500;
                        border-radius : 0 30px;
                        margin-top: 0;
                        &:hover {
                            background: ${colors.red};
                        }
                    }
                }

                @media only screen and (max-width: 575px) {
                    padding: 20px 25px 25px;
                }
            }

            @media only screen and (max-width: 575px) {
                padding: 45px 0;
            }
        }
    }
`;