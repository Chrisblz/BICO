import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .coming-soon-page {
        .coming-soon-area {
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            height: 900px;
            position: relative;
            .cm-table {
                display: table;
                width: 100%;
                height: 100%;
                .cm-tablecell {
                    display: table-cell;
                    vertical-align: middle;
                    .cm-box {
                        .cm-logo {
                            img {
                                margin-bottom: 15px;
                            }
                        }
                        .cm-text {
                            p {
                                font-size: 56px;
                                color: ${colors.black1};
                                font-weight: 600;
                                margin-bottom: 30px;

                                @media only screen and (max-width: 767px) {
                                    font-size: 46px;
                                }

                                @media only screen and (max-width: 575px) {
                                    font-size: 32px;
                                }
                            }
                        }
                        .cm-countdown {
                            margin-bottom: 30px;
                            ul {
                                li {
                                    font-size: 15px;
                                    color: ${colors.text1};
                                    text-transform: capitalize;
                                    font-weight: 500;
                                    text-align: center;
                                    margin-right: 30px;
                                    h1 {
                                        font-size: 102px;
                                        color: ${colors.black1};
                                        font-weight: 600;
                                        margin-bottom: -10px;

                                        @media only screen and (max-width: 767px) {
                                            font-size: 66px;
                                        }

                                        @media only screen and (max-width: 575px) {
                                            font-size: 46px;
                                        }
                                    }
                                    &:last-child {
                                        margin-right: 0;
                                    }

                                    @media only screen and (max-width: 991px) {
                                        margin-right: 20px;
                                    }

                                    @media only screen and (max-width: 575px) {
                                        margin-right: 8px;
                                    }
                                }
                                span {
                                    font-size: 82px;
                                    color: ${colors.red};
                                    display: inline-block;
                                    transform: translateY(-24%);
                                    margin-right: 30px;
                                    font-weight: 500;

                                    @media only screen and (max-width: 991px) {
                                        margin-right: 20px;
                                    }

                                    @media only screen and (max-width: 767px) {
                                        font-size: 62px;
                                    }

                                    @media only screen and (max-width: 575px) {
                                        font-size: 46px;
                                        margin-right: 8px;
                                    }
                                }
                            }
                        }
                        .cm-subscribe {
                            margin-bottom: 35px;
                            form {
                                position: relative;
                                max-width: 440px;
                                border-radius: 25px;
                                overflow: hidden;
                                input {
                                    width: 100%;
                                    height: 45px;
                                    background-color: rgba(255, 255, 255, 0.5);
                                    font-size: 15px;
                                    padding: 15px 25px;
                                    color: ${colors.black2};
                                    border: none;
                                    &::placeholder {
                                        color: ${colors.text2};
                                    }
                                }
                                button {
                                    background: ${colors.blue};
                                    border: none;
                                    font-size: 16px;
                                    color: #ffffff;
                                    position: absolute;
                                    top: 0;
                                    right: 0;
                                    width: 120px;
                                    height: 45px;
                                    &:hover {
                                        background: ${colors.red};
                                    }
                                }

                                @media only screen and (max-width: 767px) {
                                    max-width: 100%;
                                }

                                @media only screen and (max-width: 575px) {
                                    max-width: 400px;
                                    margin: auto;
                                }
                            }
                        }

                        .cm-social {
                            ul {
                                li {
                                    a {
                                        i {
                                            font-size: 15px;
                                            color: #ffffff;
                                            display: inline-block;
                                            width: 37px;
                                            height: 37px;
                                            text-align: center;
                                            padding-top: 12px;
                                            border-radius: 0 12px 0;
                                            &:hover {
                                                background: ${colors.red} !important;
                                            }
                                        }
                                        
                                        i.fa-facebook-f {
                                            background: #4267b2;
                                        }
                                        i.fa-twitter {
                                            background: #1da1f2;
                                        }
                                        i.fa-linkedin-in {
                                            background: #2867b2;
                                        }
                                        i.fa-instagram {
                                            background: #3f729b;
                                        }
                                        i.fa-pinterest-p {
                                            background: #E60023 ;
                                        }
                                    }
                                }
                            }
                        }

                        @media only screen and (max-width: 767px) {
                            text-align: center;
                        }
                    }
                }
            }

            @media only screen and (max-width: 767px) {
                height: 650px;
            }

            @media only screen and (max-width: 480px) {
                height: 500px;
            }
        }
    }
`;