import React from 'react';
import Datas from '../../data/coming-soon/coming-soon.json';
import Timer from 'react-compound-timer';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/comingSoon.js";

const ComingSoon = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper coming-soon-page">

                {/* Coming Soon Area */}
                <section className="coming-soon-area" style={{ backgroundImage: `url(${process.env.PUBLIC_URL}/assets/images/${Datas.backgroundImage})` }}>
                    <div className="cm-table">
                        <div className="cm-tablecell">
                            <Container>
                                <Row>
                                    <Col md="12">
                                        <div className="cm-box">
                                            <div className="cm-logo">
                                                <img src={process.env.PUBLIC_URL + `/assets/images/logo.png`} alt="" />
                                            </div>
                                            <div className="cm-text">
                                                <p>Coming Soon</p>
                                            </div>
                                            <div className="cm-countdown">
                                                <Timer initialTime={1040 * 2950 * 980} direction="backward">
                                                    <ul className="list-unstyled list-inline">
                                                        <li className="list-inline-item"><h1><Timer.Days /></h1>Days</li><span>:</span>
                                                        <li className="list-inline-item"><h1><Timer.Hours /></h1>Hours</li><span>:</span>
                                                        <li className="list-inline-item"><h1><Timer.Minutes /></h1>Minutes</li><span>:</span>
                                                        <li className="list-inline-item"><h1><Timer.Seconds /></h1>Seconds</li>
                                                    </ul>
                                                </Timer>
                                            </div>
                                            <div className="cm-subscribe">
                                                <form action="#">
                                                    <input type="text" placeholder="Enter email address" />
                                                    <button type="submit">Subscribe</button>
                                                </form>
                                            </div>
                                            <div className="cm-social">
                                                <div className="contact-social">
                                                    <ul className="list-unstyled list-inline">
                                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-pinterest-p"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                </Row>
                            </Container>
                        </div>
                    </div>
                </section>

            </div>
        </Styles>
    )
}

export default ComingSoon