import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/error.js";

const Question = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper error-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Error 404" />

                {/* Questions Area */}
                <section className="error-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <div className="error-box text-center">
                                    <h3>Sorry Page Not Found</h3>
                                    <h1>4<span>0<i className="flaticon-cleaning-brush"></i></span>4</h1>
                                    <p>The page you are looking for is not found. Go to homepage and search again.</p>
                                    <Link to={process.env.PUBLIC_URL + "/"}>Go To Homepage</Link>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default Question