import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .error-page {
        .error-area {
            padding: 65px 0 72px;
            .error-box {
                h3 {
                    color: ${colors.black2};
                    font-weight: 600;
                }
                h1 {
                    font-size: 232px;
                    color: ${colors.black1};
                    font-weight: 600;
                    span {
                        display: inline-block;
                        font-size: 152px;
                        margin: 0 15px;
                        position: relative;
                        i {
                            font-size: 44px;
                            color: ${colors.blue};
                            position: absolute;
                            top: -20px;
                            left: 23px;

                            @media only screen and (max-width: 575px) {
                                font-size: 36px;
                                top: -14px;
                                left: 17px;
                            }

                            @media only screen and (max-width: 480px) {
                                font-size: 24px;
                                top: -14px;
                                left: 13px;
                            }
                        }

                        @media only screen and (max-width: 575px) {
                            font-size: 120px;
                            margin: 0 10px;
                        }

                        @media only screen and (max-width: 480px) {
                            font-size: 86px;
                            margin: 0 5px;
                        }
                    }

                    @media only screen and (max-width: 575px) {
                        font-size: 180px;
                    }

                    @media only screen and (max-width: 480px) {
                        font-size: 136px;
                    }
                }
                p {
                    font-size: 20px;
                    color: ${colors.text2};
                    max-width: 530px;
                    margin: auto;
                    font-weight: 500;
                    margin-bottom: 40px;

                    @media only screen and (max-width: 480px) {
                        font-size: 16px;
                    }
                }
                a {
                    color: #fff;
                    background-color: ${colors.red};
                    border: none;
                    font-size: 17px;
                    font-weight: 500;
                    border-radius: 0 30px 0;
                    display: inline-block;
                    width: 240px;
                    height: 45px;
                    padding-top: 10px;
                    &:hover {
                        background-color: ${colors.blue};
                    }

                    @media only screen and (max-width: 480px) {
                        font-size: 15px;
                        width: 180px;
                        height: 42px;
                    }
                }
            }

            @media only screen and (max-width: 575px) {
                padding: 40px 0 45px;
            }
        }
    }
`;