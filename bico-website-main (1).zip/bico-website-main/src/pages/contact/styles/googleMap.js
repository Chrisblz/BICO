import styled from "styled-components";

export const Styles = styled.div`
    .google-map-area {
        width: 100%;
        height: 500px;
        margin-top: 70px;
    }
`;