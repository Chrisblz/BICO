import React from 'react';
import Datas from '../../../data/project/details.json';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";

class ProjectDetailsSlider extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        const settings = {
            dots: true,
            arrows: false,
            fade: true,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            speed: 1000,
            autoplaySpeed: 5000,
            cssEase: "linear",
            pauseOnHover: true,
            appendDots: dots => <ul>{dots}</ul>,
            customPaging: i => (
                <button><span></span></button>
            )
        };
        return (
            <Slider {...settings}>
                {
                    this.state.Data.map((data, i) => (
                        <div className="slider-item" key={i}>
                            <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} className="slider-image img-fluid" alt={data.imgUrl} />
                        </div>
                    ))
                }
            </Slider>
        )
    }
}

export default ProjectDetailsSlider