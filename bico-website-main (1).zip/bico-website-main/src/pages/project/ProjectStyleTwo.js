import React from 'react';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ProjectTwo from './../../components/project/ProjectTwo';
import Banner from '../../components/banner/Banner';
import TeamSlider from '../../components/team/TeamSlider';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/projectStyleTwo.js";

const ProjectStyleTwo = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper project-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Our Project" />

                {/* Project Area */}
                <ProjectTwo />

                {/* Banner Area */}
                <Banner />

                {/* Team Area */}
                <TeamSlider />

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ProjectStyleTwo