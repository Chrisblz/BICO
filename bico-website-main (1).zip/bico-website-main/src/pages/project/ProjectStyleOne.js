import React from 'react';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import Project from '../../components/project/Project';
import Banner from '../../components/banner/Banner';
import TeamSlider from '../../components/team/TeamSlider';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/projectStyleOne.js";

const ProjectStyleOne = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper project-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Our Project" />

                {/* Project Area */}
                <Project />

                {/* Banner Area */}
                <Banner />

                {/* Team Area */}
                <TeamSlider />

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ProjectStyleOne