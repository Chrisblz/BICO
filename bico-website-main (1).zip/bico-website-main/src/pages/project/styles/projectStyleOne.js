import styled from "styled-components";

export const Styles = styled.div`
    .project-page {
        .project-area {
            padding: 65px 0 80px;

            @media only screen and (max-width: 575px) {
                padding: 40px 0 55px;
            }

            @media only screen and (max-width: 480px) {
                padding: 40px 0 30px;
            }
        }

        .banner-area {
            @media only screen and (max-width: 480px) {
                display: none;
            }
        }

        .team-slider-area {
            padding: 205px 0 65px;

            @media only screen and (max-width: 991px) {
                padding: 165px 0 66px;
            }

            @media only screen and (max-width: 767px) {
                padding: 200px 0 66px;
            }

            @media only screen and (max-width: 575px) {
                padding: 190px 0 40px;
            }

            @media only screen and (max-width: 480px) {
                padding: 35px 0 40px;
            }
        }
    }
`;