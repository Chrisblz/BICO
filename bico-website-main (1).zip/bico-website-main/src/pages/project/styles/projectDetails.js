import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .project-details {
        .project-details-area {
            padding: 70px 0 47px;
            .project-content {
                .project-slider {
                    margin-bottom: 20px;
                    .slider-item {
                        img {
                            border-radius: 25px;
                        }
                    }
                    ul.slick-dots {
                        list-style: none;
                        position: absolute;
                        bottom: 25px;
                        left: 50%;
                        margin-left: -25px;
                        li {
                            margin: 0 3px;
                            display: inline-block;
                            button {
                                border: none;
                                background: rgba(255, 255, 255, 0.6);
                                width: 18px;
                                height: 18px;
                                border-radius: 0 8px;
                                span {

                                }
                            }
                        }
                        li.slick-active {
                            button {
                                background: ${colors.blue}; 
                            }
                        }
                    }
                }
                .project-description {
                    margin-bottom: 20px;
                    h5 {
                        color: ${colors.black1};
                        font-weight: 700;
                        margin-bottom: 15px;
                    }
                    p {
                        font-size: 15px;
                        color: ${colors.text2};
                        line-height: 27px;
                    }
                }

                .project-challenge {
                    margin-bottom: 20px;
                    h5 {
                        color: ${colors.black1};
                        font-weight: 700;
                        margin-bottom: 15px;
                    }
                    p {
                        font-size: 15px;
                        color: ${colors.text2};
                        line-height: 27px;
                        margin-bottom: 20px;
                    }
                    ul {
                        li {
                            font-size: 14px;
                            color: ${colors.text2};
                            line-height: 25px;
                            margin-bottom: 10px;
                            i {
                                font-size: 28px;
                                color: ${colors.blue};
                                margin-right: 8px;
                                float: left;
                                height: 35px;
                                transform: translateY(25%);
                            }

                            &:last-child {
                                margin-bottom: 0;
                            }
                        }
                    }
                }

                .project-solution {
                    margin-bottom: 20px;
                    h5 {
                        color: ${colors.black1};
                        font-weight: 700;
                        margin-bottom: 15px;
                    }
                    p {
                        font-size: 15px;
                        color: ${colors.text2};
                        line-height: 27px;
                        margin-bottom: 20px;
                    }
                    ul {
                        margin-bottom: 20px;
                        li {
                            font-size: 14px;
                            color: ${colors.text2};
                            line-height: 25px;
                            margin-bottom: 10px;
                            i {
                                font-size: 28px;
                                color: ${colors.blue};
                                margin-right: 8px;
                                float: left;
                                height: 35px;
                                transform: translateY(25%);
                            }

                            &:last-child {
                                margin-bottom: 0;
                            }
                        }
                    }
                }

                @media only screen and (max-width: 767px) {
                    margin-bottom: 20px;
                }
            }

            .pro-details-sidebar {
                .pro-details-info {
                    border : 1px solid ${colors.border3};
                    padding: 18px 18px 15px;
                    border-radius : 15px;
                    margin-bottom: 30px;
                    h6 {
                        color : ${colors.black1};
                        margin-bottom: 20px;
                        position: relative;
                        &:before {
                            position: absolute;
                            content: "";  
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -10px;
                            left: 0;
                        }
                        &:after {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -8px;
                            left: 0;
                        }
                    }
                    ul {
                        li {
                            font-size: 14px;
                            color: ${colors.black1};
                            line-height: 36px;
                            span {
                                float: right;
                                color: ${colors.blue};
                            }

                            ul.rating {
                                float: right;
                                li {
                                    i {
                                        font-size: 16px;
                                        color: ${colors.yellow};
                                        margin-left: -5px;
                                    }
                                }
                            }

                            ul.share {
                                float: right;
                                li {
                                    line-height: 0;
                                    a {
                                        i {
                                            font-size: 12px;
                                            color: #ffffff;
                                            display: inline-block;
                                            width: 25px;
                                            height: 25px;
                                            text-align: center;
                                            padding-top: 7px;
                                            border-radius: 0 10px 0;
                                            &:hover {
                                                background: ${colors.red} !important;
                                            }
                                        }
                                        i.fa-facebook-f {
                                            background: #4267b2;
                                        }
                                        i.fa-twitter {
                                            background: #1da1f2;
                                        }
                                        i.fa-linkedin-in {
                                            background: #2867b2;
                                        }
                                        i.fa-instagram {
                                            background: #E60023;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    @media only screen and (max-width: 1199px) {
                        padding: 10px 8px 8px;
                    }
                }
            }

            @media only screen and (max-width: 575px) {
                padding: 40px 0 10px;
            }
        }
    }
`;