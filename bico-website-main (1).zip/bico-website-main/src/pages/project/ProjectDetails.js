import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ProjectDetailsSlider from './components/ProjectDetailsSlider';
import ServiceForm from './../service/components/ServiceForm';
import RecentPost from './../service/components/RecentPost';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/projectDetails.js";

const ProjectDetails = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper project-details">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Project Details" />

                {/* Project Details Area */}
                <section className="project-details-area">
                    <Container>
                        <Row>
                            <Col lg="9" md="7">
                                <div className="project-content">
                                    <Row>
                                        <Col md="12">
                                            <div className="project-slider">
                                                <ProjectDetailsSlider />
                                            </div>
                                        </Col>
                                        <Col md="12">
                                            <div className="project-description">
                                                <h5>Project Description</h5>
                                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Similique, obcaecati rerum! Fugit est veritatis ex cum eum dolor voluptate corrupti hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde. Optio temporibus eos libero odit ipsum placeat soluta quae dolorem tempore, repudiandae debitis sed, expedita consectetur Non voluptatibus et repellendus inventore itaque.<br /><br /> Qxplicabo tempore atque a at nulla, quis dolore ullam temporibus quidem inventore. Iste omnis provident tempora dolorem quos rem necessitatibus voluptatem. Voluptas architecto sunt enim sint magni, quae necessitatibus. Sokim kinsk losuken expedita consectetur Non voluptatibus.</p>
                                            </div>
                                            <div className="project-challenge">
                                                <h5>Project Challenges</h5>
                                                <p>Fugit est veritatis ex cum eum dolor voluptate corrupti hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde. Optio temporibus eos libero odit ipsum placeat soluta quae dolorem tempore, repudiandae debitis sed, expedita consectetur Non voluptatibus et repellendus inventore quae necessitatibus.</p>
                                                <ul className="icon-box list-unstyled">
                                                    <li>
                                                        <i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet onsectetur adipisicing consect minixe dimare tana hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde.
                                                    </li>
                                                    <li>
                                                        <i className="las la-check-circle"></i>Obcaecati makam  labore nihil hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde kisim maxime lopu namkinse vitae tempora.
                                                    </li>
                                                    <li>
                                                        <i className="las la-check-circle"></i>Quidem totam quas rerum hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde cupiditate culpa consec nostrm sapan iksim ipsa soqu.
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="project-solution">
                                                <h5>Project Solutions</h5>
                                                <p>Fugit est veritatis ex cum eum dolor voluptate corrupti hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde. Optio temporibus eos libero odit ipsum placeat soluta quae dolorem tempore, repudiandae debitis sed, expedita consectetur Non voluptatibus et repellendus inventore quae necessitatibus.</p>
                                                <ul className="icon-box list-unstyled">
                                                    <li>
                                                        <i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet onsectetur adipisicing consect minixe dimare tana hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde.
                                                    </li>
                                                    <li>
                                                        <i className="las la-check-circle"></i>Obcaecati makam  labore nihil hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde kisim maxime lopu namkinse vitae tempora.
                                                    </li>
                                                    <li>
                                                        <i className="las la-check-circle"></i>Quidem totam quas rerum hic earum delectus perferendis omnis optio, accusantium recusandae, eveniet unde cupiditate culpa consec nostrm sapan iksim ipsa soqu.
                                                    </li>
                                                    <li>
                                                        <i className="las la-check-circle"></i>Pinoei kislim quas rerum hic earum disim delectus perferendis omnis optio, accusantium recusandae, eveniet unde cupiditate culpa consec nostrm iksim ipsa.
                                                    </li>
                                                </ul>
                                                <p>Delectus perferendis omnis optio, accusantium recusandae, eveniet unde. Optio temporibus eos libero odit ipsum placeat soluta quae dolorem tempore, repudiandae debitis sed, expedita consectetur Non voluptatibus et repellendus inventore quae necessitatibus.</p>
                                            </div>
                                        </Col>
                                    </Row>
                                </div>
                            </Col>

                            <Col lg="3" md="4">
                                <div className="pro-details-sidebar">
                                    <Row>
                                        <Col md="12">
                                            <div className="pro-details-info">
                                                <h6>Project Information</h6>
                                                <ul className="list-unstyled">
                                                    <li>Client :<span>Jhon Doe</span></li>
                                                    <li>Category :<span>House Cleaning</span></li>
                                                    <li>Price :<span>$499</span></li>
                                                    <li>Date :<span>Apr 23, 2021</span></li>
                                                    <li>Website :<span>mydomain.com</span></li>
                                                    <li>Rating :
                                                        <ul className="rating list-unstyled list-inline">
                                                            <li className="list-inline-item"><i className="las la-star"></i></li>
                                                            <li className="list-inline-item"><i className="las la-star"></i></li>
                                                            <li className="list-inline-item"><i className="las la-star"></i></li>
                                                            <li className="list-inline-item"><i className="las la-star"></i></li>
                                                            <li className="list-inline-item"><i className="las la-star"></i></li>
                                                        </ul>
                                                    </li>
                                                    <li>Share :
                                                        <ul className="share list-unstyled list-inline">
                                                            <li className="list-inline-item"><a href="/"><i className="fab fa-facebook-f"></i></a></li>
                                                            <li className="list-inline-item"><a href="/"><i className="fab fa-twitter"></i></a></li>
                                                            <li className="list-inline-item"><a href="/"><i className="fab fa-linkedin-in"></i></a></li>
                                                            <li className="list-inline-item"><a href="/"><i className="fab fa-instagram"></i></a></li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </Col>
                                        <Col md="12">
                                            <ServiceForm />
                                        </Col>
                                        <Col md="12">
                                            <RecentPost />
                                        </Col>
                                    </Row>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default ProjectDetails