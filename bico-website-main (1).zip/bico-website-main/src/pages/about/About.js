import React from 'react';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import AboutUsTwo from '../../components/about/AboutUsTwo';
import WhyUs from '../../components/why-us/WhyUs';
import Faq from './../../components/faq/Faq';
import CustomerCare from './../../components/customer-care/CustomerCare';
import TeamSlider from './../../components/team/TeamSlider';
import Footer from './../../components/footer/Footer';
import { Styles } from "./styles/about.js";

const About = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper about-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="About Us" />

                {/* About Area */}
                <AboutUsTwo />

                {/* Why Us Area */}
                <WhyUs />

                {/* Faq Area */}
                <Faq />

                {/* Customer Care Area */}
                <CustomerCare />

                {/* Team Area */}
                <TeamSlider />

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default About