import React from 'react';
import { Row, Col } from 'react-bootstrap';
import BlogSearch from './components/BlogSearch';
import BlogCategory from './components/BlogCategory';
import RecentPost from './../service/components/RecentPost';
import BlogTag from './../blog/components/BlogTag';

const BlogSidebar = () => {
    return (
        <div className="blog-sidebar-area">
            <Row>
                <Col md="12">
                    <BlogSearch />
                </Col>
                <Col md="12">
                    <BlogCategory />
                </Col>
                <Col md="12">
                    <RecentPost />
                </Col>
                <Col md="12">
                    <BlogTag />
                </Col>
            </Row>
        </div>
    )
}

export default BlogSidebar