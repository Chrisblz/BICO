import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import GridItem from './components/GridItem';
import Pagination from './components/Pagination';
import BlogSidebar from './BlogSidebar';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/blogGrid.js";

const BlogGrid = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper blog-grid-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Blog Grid" />

                {/* Blog Area */}
                <section className="blog-grid-area">
                    <Container>
                        <Row>
                            <Col lg="9" md="8">
                                <GridItem />
                                <Pagination />
                            </Col>
                            <Col lg="3" md="4">
                                <BlogSidebar />
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default BlogGrid