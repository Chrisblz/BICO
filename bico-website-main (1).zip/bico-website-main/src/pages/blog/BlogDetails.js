import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import CommentForm from './components/CommentForm';
import BlogSidebar from './BlogSidebar';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/blogDetails.js";

const BlogDetails = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper blog-details-page">

                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Blog Details" />

                {/* Blog Area */}
                <section className="blog-details-area">
                    <Container>
                        <Row>
                            <Col lg="9" md="8">
                                <div className="blog-details-box">
                                    <div className="blog-details-banner">
                                        <img src={process.env.PUBLIC_URL + `/assets/images/blog-9.jpg`} alt="" className="img-fluid" />
                                    </div>

                                    <div className="blog-auth_date d-flex">
                                        <div className="post-author">
                                            <img src={process.env.PUBLIC_URL + `/assets/images/author.jpg`} alt="" />
                                            <Link to={process.env.PUBLIC_URL + "/"}>Jhon Doe</Link>
                                        </div>
                                        <div className="post-date">
                                            <p><i className="las la-calendar"></i>Jan 12, 2021</p>
                                        </div>
                                        <div className="post-tag">
                                            <p><i className="las la-bookmark"></i>Home Clean</p>
                                        </div>
                                        <div className="post-comment">
                                            <p><i className="las la-comment"></i>(31)</p>
                                        </div>
                                    </div>
                                    <div className="blog-heading">
                                        <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam sunt nemo maiores magni, tempora iste architecto</h5>
                                    </div>
                                    <div className="blog-desc">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum officia nisi modi iusto, eligendi ducimus. Eveniet amet explicabo nesciunt quia quis perspiciatis praesentium incidunt accusamus enim id volupta, architecto sit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga non provident enim sint iure unde fugit illum! Obcaecati nam sequi, nisi ut dicta corrupti debitis possimus eum. Eveniet amet explicabo nesciunt quia quis perspiciatis praesentium incidunt accusamus enim id volupta, architecto sit.<br /><br /> Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui modi repellendus atque aperiam, perspiciatis officia nemo esse, fuga est deleniti perferendis, doloribus odio maxime dignissimos suscipit dolore corporis repudiandae asperiores. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                    </div>
                                    <div className="quote-box d-flex">
                                        <div className="quote-icon">
                                            <i className="flaticon-quotes-left"></i>
                                        </div>
                                        <div className="quote-text">
                                            <p>Modi dolores ad esse distinctio corporis sapiente obcaecati eveniet amet explicabo nesciunt quia quis perspiciatis praesentium incidunt accusamus enim id volupta dolore.</p>
                                        </div>
                                    </div>
                                    <div className="blog-desc">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum officia nisi modi iusto, eligendi ducimus. Eveniet amet explicabo nesciunt quia quis perspiciatis praesentium incidunt accusamus enim id volupta, architecto sit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga non provident enim sint iure unde fugit illum! Obcaecati nam sequi, nisi ut dicta corrupti debitis possimus eum.</p>
                                    </div>
                                    <div className="ico-overview">
                                        <Row>
                                            <Col lg="5" md="0">
                                                <div className="ico-img">
                                                    <img src={process.env.PUBLIC_URL + `/assets/images/blog-d-icon.jpg`} alt="" className="img-fluid" />
                                                </div>
                                            </Col>
                                            <Col lg="7" md="12">
                                                <div className="ico-content">
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem totam alias eius doloribus, itaque blanditiis tenetur velit sokam magni commodi adipisci reiciendis do recusandae dishek mera ratione onim eaque.</p>
                                                    <span>Perferendi amet accusamus ratione solim calasu kasm key maxime quaerat.</span>
                                                    <ul className="icon-box list-unstyled">
                                                        <li>
                                                            <i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet onsectetur adipisicing consect minixe dimare tana.
                                                        </li>
                                                        <li>
                                                            <i className="las la-check-circle"></i>Obcaecati makam  labore nihil kisim maxime lopu namkinse vitae tempora.
                                                        </li>
                                                        <li>
                                                            <i className="las la-check-circle"></i>Quidem totam quas rerum cupiditate culpa consec nostrm sapan iksim ipsa soqu.
                                                        </li>
                                                    </ul>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="blog-tag_share d-flex justify-content-between">
                                        <div className="blog-tag">
                                            <ul className="tags list-unstyled list-inline">
                                                <li className="list-inline-item">Tags:</li>
                                                <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/"}>Html</Link></li>
                                                <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/"}>Design</Link></li>
                                                <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/"}>Develop</Link></li>
                                                <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/"}>React</Link></li>
                                            </ul>
                                        </div>
                                        <div className="blog-share">
                                            <ul className="social list-unstyled list-inline">
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="blog-comments">
                                        <h5>Comments (03)</h5>
                                        <div className="comment-box d-flex">
                                            <div className="comment-image">
                                                <img src={process.env.PUBLIC_URL + `/assets/images/comment-1.jpg`} alt="" />
                                            </div>
                                            <div className="comment-content">
                                                <div className="content-title d-flex justify-content-between">
                                                    <div className="comment-writer">
                                                        <h6>Mark Shadow</h6>
                                                        <p>Mar 26, 2020 | 06:30pm</p>
                                                    </div>
                                                    <div className="reply-btn">
                                                        <button type="button">Reply</button>
                                                    </div>
                                                </div>
                                                <div className="comment-desc">
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto laborum quas placeat perspiciatis est, nisi expedita consectetur sit minus illum laudantium.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="comment-box d-flex comment-active">
                                            <div className="comment-image">
                                                <img src={process.env.PUBLIC_URL + `/assets/images/comment-2.jpg`} alt="" />
                                            </div>
                                            <div className="comment-content">
                                                <div className="content-title d-flex justify-content-between">
                                                    <div className="comment-writer">
                                                        <h6>Katrin Kay</h6>
                                                        <p>Mar 26, 2020 | 06:30pm</p>
                                                    </div>
                                                    <div className="reply-btn">
                                                        <button type="button">Reply</button>
                                                    </div>
                                                </div>
                                                <div className="comment-desc">
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto laborum quas placeat perspiciatis est, nisi expedita consectetur sit.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="comment-box d-flex">
                                            <div className="comment-image">
                                                <img src={process.env.PUBLIC_URL + `/assets/images/comment-1.jpg`} alt="" />
                                            </div>
                                            <div className="comment-content">
                                                <div className="content-title d-flex justify-content-between">
                                                    <div className="comment-writer">
                                                        <h6>David Show</h6>
                                                        <p>Mar 26, 2020 | 06:30pm</p>
                                                    </div>
                                                    <div className="reply-btn">
                                                        <button type="button">Reply</button>
                                                    </div>
                                                </div>
                                                <div className="comment-desc">
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto laborum quas placeat perspiciatis est, nisi expedita consectetur sit minus illum laudantium.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <CommentForm />
                                </div>
                            </Col>
                            <Col lg="3" md="4">
                                <BlogSidebar />
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default BlogDetails