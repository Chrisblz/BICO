import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import HeaderTwo from '../../components/header/HeaderTwo';
import { BreadcrumbBox } from '../../components/common/Breadcrumb';
import ClassicItem from './components/ClassicItem';
import Pagination from './components/Pagination';
import BlogSidebar from './BlogSidebar';
import Footer from '../../components/footer/Footer';
import { Styles } from "./styles/blogClassic.js";

const BlogClassic = () => {
    return (
        <Styles>
            {/* Main Wrapper */}
            <div className="main-wrapper blog-classic-page">
                
                {/* Header Area */}
                <HeaderTwo />

                {/* Breadcroumb */}
                <BreadcrumbBox title="Blog Classic" />

                {/* Blog Area */}
                <section className="blog-classic-area">
                    <Container>
                        <Row>
                            <Col lg="9" md="8">
                                <ClassicItem />
                                <Pagination />
                            </Col>
                            <Col lg="3" md="4">
                                <BlogSidebar />
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Footer Area */}
                <Footer />

            </div>
        </Styles>
    )
}

export default BlogClassic