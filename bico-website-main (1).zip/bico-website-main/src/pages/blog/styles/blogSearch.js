import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .blog-search {
        border : 1px solid ${colors.border3};
        padding: 18px 18px 20px;
        border-radius : 15px;
        margin-bottom: 30px;
        h6 {
            color : ${colors.black1};
            margin-bottom: 32px;
            position: relative;
            &:before {
                position: absolute;
                content: "";  
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -10px;
                left: 0;
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -8px;
                left: 0;
            }
        }

        form {
            position: relative;
            input {
                width : 100%;
                height: 42px;
                border: 1px solid ${colors.blue};
                color : ${colors.black1};
                border-radius: 10px;
                padding-left: 15px;
                &:focus {
                    border-color : ${colors.blue};
                }
                &::placeholder {
                    font-size  : 14px;
                    font-style : italic;
                    color      : ${colors.black2};
                    font-weight: 400;
                }
            }
            button {
                position: absolute;
                width: 45px;
                height: 100%;
                top: 0;
                right: 0;
                background: transparent;
                padding: 0;
                border: none;
                font-size: 20px;
                color: ${colors.red};
            }
        }
    }
`;