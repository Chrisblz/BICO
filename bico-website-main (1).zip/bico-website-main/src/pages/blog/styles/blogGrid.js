import styled from "styled-components";

export const Styles = styled.div`
    .blog-grid-page {
        .blog-grid-area {
            padding: 70px 0;

            @media only screen and (max-width: 575px) {
                padding: 40px 0;
            }
        }

        .blog-sidebar-area {
            @media only screen and (max-width: 767px) {
                margin-top: 50px;
            }
        }
    }
`;