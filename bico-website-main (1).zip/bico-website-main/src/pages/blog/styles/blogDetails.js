import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .blog-details-page {
        .blog-details-area {
            padding: 70px 0;
            .blog-details-box {
                .blog-details-banner {
                    img {
                        border-radius: 25px;
                        margin-bottom: 20px;
                    }
                }
                .blog-auth_date {
                    margin-bottom: 12px;
                    .post-author {
                        margin-right: 20px;
                        img {
                            width: 35px;
                            border-radius: 0 35%;
                            float: left;
                            margin-right: 10px;
                        }
                        a {
                            float: left;
                            font-size: 14px;
                            color: ${colors.blue};
                            font-weight: 500;
                            transform: translateY(30%);
                            &:hover {
                                color: ${colors.red};
                            }
                        }

                        @media only screen and (max-width: 480px) {
                            margin-right: 10px;
                        }
                    }
                    .post-date {
                        padding-top: 4px;
                        margin-right: 20px;
                        p {
                            font-size: 14px;
                            color: ${colors.text2};
                            font-weight: 500;
                            i {
                                font-size: 20px;
                                color: ${colors.blue};
                                margin-right: 3px;
                                transform: translateY(12%);
                            }
                        }

                        @media only screen and (max-width: 480px) {
                            margin-right: 10px;
                        }
                    }
                    .post-tag {
                        padding-top: 3px;
                        margin-right: 20px;
                        p {
                            font-size: 14px;
                            color: ${colors.text2};
                            text-transform: capitalize;
                            font-weight: 500;
                            i {
                                font-size: 20px;
                                color: ${colors.blue};
                                margin-right: 3px;
                                transform: translateY(12%);
                            }
                        }

                        @media only screen and (max-width: 480px) {
                            margin-right: 10px;
                        }
                    }
                    .post-comment {
                        padding-top: 3px;
                        p {
                            font-size: 14px;
                            color: ${colors.text2};
                            text-transform: capitalize;
                            font-weight: 500;
                            i {
                                font-size: 20px;
                                color: ${colors.blue};
                                margin-right: 3px;
                                transform: translateY(12%);
                            }
                        }
                    }
                }
                .blog-heading {
                    h5 {
                        color: ${colors.black1};
                        font-weight: 600;
                        line-height: 30px;
                        letter-spacing: 0.5px;
                        margin-bottom: 25px;
                    }
                }
                .blog-desc {
                    p {
                        font-size: 15px;
                        color: ${colors.text2};
                        line-height: 28px;
                        margin-bottom: 30px;
                    }
                }
                .quote-box {
                    margin-bottom: 25px;
                    .quote-icon {
                        i {
                            font-size: 42px;
                            color: ${colors.blue};
                            display: block;
                            margin-top: 2px;
                            margin-right: 12px;
                        }
                    }
                    .quote-text {
                        p {
                            font-size: 18px;
                            color: ${colors.black1};
                            font-weight: 600;
                            line-height: 30px;

                            @media only screen and (max-width: 575px) {
                                font-size: 15px;
                            }
                        }
                    }
                    
                }

                .ico-overview {
                    margin-bottom: 40px;
                    .ico-img {
                        img {
                            border-radius: 20px;
                        }

                        @media only screen and (max-width: 991px) {
                            display: none;
                        }
                    }
                    .ico-content {
                        h5 {
                            color: ${colors.black1};
                            font-weight: 700;
                            margin-bottom: 15px;
                        }
                        p {
                            font-size: 14px;
                            color: ${colors.text1};
                            line-height: 27px;
                            margin-bottom: 15px;
                        }
                        span {
                            font-size: 16px;
                            color: ${colors.red};
                            font-weight: 600;
                            display: block;
                            margin-bottom: 25px;
                            line-height: 25px;
                        }
                        ul {
                            li {
                                font-size: 14px;
                                color: ${colors.text2};
                                line-height: 25px;
                                margin-bottom: 10px;
                                i {
                                    font-size: 24px;
                                    color: ${colors.blue};
                                    margin-right: 8px;
                                    float: left;
                                    height: 35px;
                                    transform: translateY(8%);
                                }

                                &:last-child {
                                    margin-bottom: 0;
                                }
                            }
                        }
                    }
                }

                .blog-tag_share {
                    margin-bottom: 40px;
                    .blog-tag {
                        ul.tags {
                            li {
                                color : ${colors.text3};
                                a {
                                    font-size: 13px;
                                    color: ${colors.text2};
                                    border: 1px solid ${colors.border3};
                                    padding: 5px 12px;
                                    display: inline-block;
                                    border-radius: 0 15px 0;
                                    &:hover {
                                        background: ${colors.red};
                                        color: #ffffff;
                                        border-color: ${colors.red};
                                    }
                                }
                                &:first-child {
                                    font-size: 15px;
                                    color: ${colors.black1};
                                    font-weight: 600;
                                    margin-right: 10px;
                                }
                            }
                        }

                        @media only screen and (max-width: 480px) {
                            margin-bottom: 10px;
                        }
                    }
                    .blog-share {
                        ul.social {
                            li {
                                a {
                                    i {
                                        font-size: 14px;
                                        color: #ffffff;
                                        display: inline-block;
                                        width: 30px;
                                        height: 30px;
                                        text-align: center;
                                        padding-top: 9px;
                                        border-radius: 0 12px 0;
                                        &:hover {
                                            background: ${colors.red} !important;
                                        }
                                    }
                                    
                                    i.fa-facebook-f {
                                        background: #4267b2;
                                    }
                                    i.fa-twitter {
                                        background: #1da1f2;
                                    }
                                    i.fa-linkedin-in {
                                        background: #2867b2;
                                    }
                                    i.fa-instagram {
                                        background: #3f729b;
                                    }
                                }
                            }
                        }
                    }

                    @media only screen and (max-width: 480px) {
                        display: block !important;
                    }
                }

                .blog-comments {
                    margin-bottom: 45px;
                    h5 {
                        color: ${colors.black1};
                        font-weight: 600;
                        margin-bottom: 35px;
                        position: relative;
                        &:before {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -10px;
                            left: 0;
                        }
                        &:after {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -8px;
                            left: 0;
                        }
                    }
                    .comment-box {
                        margin-bottom: 25px;
                        .comment-image {
                            img {
                                max-width : 85px;
                                border-radius : 15px;
                                margin-right : 20px;

                                @media only screen and (max-width: 480px) {
                                    max-width : 70px;
                                    margin-right : 10px;
                                }
                            }
                        }
                        .comment-content {
                            background: ${colors.bg2};
                            padding: 20px 25px;
                            border-radius: 25px;
                            .content-title {
                                .comment-writer {
                                    h6 {
                                        color: ${colors.black2};
                                        font-weight: 600;
                                        margin-bottom : 10px;
                                    }
                                    p {
                                        font-size : 12px;
                                        color: ${colors.text3};
                                        margin-bottom: 5px;
                                    }
                                }
                                .reply-btn {
                                    button {
                                        font-size: 13px;
                                        color: #ffffff;
                                        border: none;
                                        padding: 5px 12px;
                                        font-weight: 500;
                                        display: inline-block;
                                        background: ${colors.blue};
                                        border-radius: 0 15px 0;
                                        &:hover {
                                            color : #ffffff;
                                            background : ${colors.red};
                                        }
                                    }
                                }
                            }
                            .comment-desc {
                                p {
                                    font-size: 14px;
                                    color: ${colors.text2};
                                    line-height: 25px;
                                }
                            }
                        }
                        &:last-child {
                            border-bottom : none;
                            padding-bottom : 0;
                            margin-bottom : 0;
                        }
                    }

                    .comment-box.comment-active {
                        margin-left: 60px;
                    }
                }
            }

            .blog-sidebar-area {
                @media only screen and (max-width: 767px) {
                    margin-top: 50px;
                }
            }

            @media only screen and (max-width: 575px) {
                padding: 40px 0;
            }
        }
    }
`;