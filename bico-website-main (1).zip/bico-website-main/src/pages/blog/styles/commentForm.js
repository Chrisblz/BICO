import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js";

export const Styles = styled.div`
    .blog-comment-form {
        h5 {
            color: ${colors.black1};
            font-weight: 600;
            margin-bottom: 35px;
            position: relative;
            &:before {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -10px;
                left: 0;
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -8px;
                left: 0;
            }
        }

        form.comment-form {
            p.form-box {
                padding   : 0;
                width     : auto;
                height    : auto;
                background: transparent;
                border    : none;
                margin-bottom : 30px;
                position  : relative;

                textarea.form-control {
                    width           : 100%;
                    height          : 150px;
                    background      : transparent;
                    border          : 1px solid ${colors.border3};
                    font-size       : 15px;
                    padding         : 15px 20px;
                    color           : ${colors.black2};
                    border-radius   : 25px;

                    &:focus {
                        border-color: ${colors.blue};
                        box-shadow: none;
                    }

                    &::placeholder {
                        font-size  : 15px;
                        color      : ${colors.text2};
                    }
                }

                input.form-control {
                    width           : 100%;
                    height          : 50px;
                    background      : transparent;
                    border          : 1px solid ${colors.border3};
                    font-size       : 15px;
                    padding         : 15px 20px;
                    color           : ${colors.black2};
                    border-radius   : 17px;

                    &:focus {
                        border-color: ${colors.blue};
                        box-shadow: none;
                    }

                    &::placeholder {
                        font-size  : 15px;
                        color      : ${colors.text2};
                    }
                }

                label.error {
                    font-size: 14px;
                    color: ${colors.red};
                    position: absolute;
                    top: 100%;
                    left: 0;
                    line-height: 18px;
                    letter-spacing: 0;
                }
            }

            button {
                font-size : 16px;
                color     : #fff;
                background: ${colors.red};
                width     : 180px;
                height    : 50px;
                border    : none;
                font-weight: 500;
                border-radius: 0 25px;
                margin-top: 5px;

                &:hover {
                    background: ${colors.blue};
                }

                @media only screen and (max-width: 575px) {
                    font-size: 15px;
                    width: 160px;
                    height: 45px;
                }
            }
        }
    }
`;