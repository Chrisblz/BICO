import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .blog-classic-box {
        margin-bottom: 20px;
        .blog-box {
            position: relative;
            margin-bottom: 40px;
            img.blog-img {
                border-radius: 25px;
                margin-bottom: 20px;
            }
            h5.blog-title {
                border-bottom: 1px solid ${colors.border1};
                padding-bottom: 15px;
                margin-bottom: 10px;
                a {
                    color: ${colors.black1};
                    font-weight: 500;
                    line-height: 30px;
                    letter-spacing: 0.5px;
                    &:hover {
                        color: ${colors.blue};
                    }

                    @media only screen and (max-width: 991px) {
                        font-size: 16px;
                    }
                }
            }

            .blog-text {
                .post-author {
                    margin-right: 20px;
                    img {
                        width: 35px;
                        border-radius: 0 35%;
                        float: left;
                        margin-right: 10px;
                    }
                    a {
                        float: left;
                        font-size: 14px;
                        color: ${colors.blue};
                        font-weight: 500;
                        transform: translateY(30%);
                        &:hover {
                            color: ${colors.red};
                        }
                    }

                    @media only screen and (max-width: 480px) {
                        margin-right: 5px;
                    }
                }
                .post-date {
                    padding-top: 4px;
                    margin-right: 20px;
                    p {
                        font-size: 14px;
                        color: ${colors.text2};
                        font-weight: 500;
                        i {
                            font-size: 20px;
                            color: ${colors.blue};
                            margin-right: 3px;
                            transform: translateY(12%);
                        }
                    }

                    @media only screen and (max-width: 480px) {
                        margin-right: 5px;
                    }
                }
                .post-tag {
                    padding-top: 3px;
                    margin-right: 20px;
                    p {
                        font-size: 14px;
                        color: ${colors.text2};
                        text-transform: capitalize;
                        font-weight: 500;
                        i {
                            font-size: 20px;
                            color: ${colors.blue};
                            margin-right: 3px;
                            transform: translateY(12%);
                        }
                    }

                    @media only screen and (max-width: 480px) {
                        margin-right: 5px;
                    }
                }
                .post-comment {
                    padding-top: 3px;
                    p {
                        font-size: 14px;
                        color: ${colors.text2};
                        text-transform: capitalize;
                        font-weight: 500;
                        i {
                            font-size: 20px;
                            color: ${colors.blue};
                            margin-right: 3px;
                            transform: translateY(12%);
                        }
                    }
                }
            }
        }
    }
`;