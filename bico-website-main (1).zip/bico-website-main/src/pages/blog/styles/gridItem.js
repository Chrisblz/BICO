import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .blog-grid-box {
        margin-bottom: 20px;
        .blog-box {
            position: relative;
            margin-bottom: 30px;
            img.blog-img {
                border-radius: 25px;
            }
            .blog-text {
                position: absolute;
                bottom: 18px;
                left: 18px;
                background: #ffffff;
                width: 90%;
                padding: 20px 22px;
                border-radius: 15px;
                span.blog-tag {
                    display: inline-block;
                    font-size: 15px;
                    color: ${colors.red};
                    text-transform: capitalize;
                    font-weight: 500;
                    margin-bottom: 8px;
                }
                h5.blog-title {
                    border-bottom: 1px solid ${colors.border1};
                    padding-bottom: 10px;
                    margin-bottom: 15px;
                    a {
                        font-size: 18px;
                        color: ${colors.black1};
                        font-weight: 600;
                        &:hover {
                            color: ${colors.blue};
                        }
                    }
                }
                .author {
                    img {
                        width: 32px;
                        border-radius: 0 50%;
                        float: left;
                        margin-right: 10px;
                    }
                    p {
                        float: left;
                        color: ${colors.text3};
                        font-weight: 500;
                        transform: translateY(30%);
                    }
                }
                .date {
                    p {
                        color: ${colors.text3};
                        font-weight: 500;
                        margin-top: 6px;
                    }
                }
            }
        }
    }
`;