import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .pagination-box {
        ul {
            li {
                margin: 0 8px;
                a {
                    font-size: 17px;
                    color: ${colors.black2};
                    width: 38px;
                    height: 38px;
                    display: block;
                    padding-top: 7px;
                    border-radius: 50%;
                    i {
                        
                    }

                    &:hover {
                        background: ${colors.red};
                        color: #ffffff;
                    }
                }
            }

            li.active {
                a {
                    background: ${colors.red};
                    color: #ffffff;
                }
            }
        }
    }
`;