import styled from "styled-components";
import { colors } from "../../../components/common/element/elements.js"

export const Styles = styled.div`
    .blog-category {
        border : 1px solid ${colors.border3};
        padding: 18px 18px 20px;
        border-radius : 15px;
        margin-bottom: 30px;
        h6 {
            color : ${colors.black1};
            margin-bottom: 32px;
            position: relative;
            &:before {
                position: absolute;
                content: "";  
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -10px;
                left: 0;
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.blue};
                width: 60px;
                height: 1px;
                bottom: -8px;
                left: 0;
            }
        }

        ul {
            li {
                a {
                    display: block;
                    background: ${colors.bg1};
                    color: ${colors.black1};
                    font-size: 14px;
                    font-weight: 500;
                    padding: 10px 18px;
                    border-radius: 8px;
                    margin-bottom: 12px;
                    &:hover {
                        background: ${colors.red};
                        color: #ffffff;
                    }
                }
                &:last-child {
                    a {
                        margin-bottom: 0;
                    }
                }
            }
        }
    }
`;