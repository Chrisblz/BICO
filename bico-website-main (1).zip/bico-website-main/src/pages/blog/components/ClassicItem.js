import React from 'react';
import Datas from '../../../data/blog/classic.json';
import { Link } from 'react-router-dom';
import { Styles } from '../styles/classicItem.js';

class Classictem extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                <div className="blog-classic-box">
                    {
                        this.state.Data.map((data, i) => (
                            <div className="blog-box" key={i}>
                                <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} alt="" className="img-fluid blog-img" />
                                <h5 className="blog-title">
                                    <Link to={process.env.PUBLIC_URL + data.postLink}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam sunt nemo maiores magni, tempora iste architecto...</Link>
                                </h5>
                                <div className="blog-text d-flex">
                                    <div className="post-author">
                                        <img src={process.env.PUBLIC_URL + `/assets/images/${data.authorImg}`} alt="" />
                                        <Link to={process.env.PUBLIC_URL + data.postLink}>{data.authorName}</Link>
                                    </div>
                                    <div className="post-date">
                                        <p><i className="las la-calendar"></i>{data.postDate}</p>
                                    </div>
                                    <div className="post-tag">
                                        <p><i className="las la-bookmark"></i>{data.postTag}</p>
                                    </div>
                                    <div className="post-comment">
                                        <p><i className="las la-comment"></i>({data.comCount})</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    }
                </div>
            </Styles>
        )
    }
}

export default Classictem