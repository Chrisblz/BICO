import React from 'react';
import { Styles } from '../styles/blogSearch.js';

const BlogSearch = () => {
    return (
        <Styles>
            {/* Blog Search */}
            <div className="blog-search">
                <h6>Blog Search</h6>
                <form action="#">
                    <input type="text" name="search" placeholder="Search Here" />
                    <button type="submit"><i className="las la-search"></i></button>
                </form>
            </div>
        </Styles>
    )
}

export default BlogSearch