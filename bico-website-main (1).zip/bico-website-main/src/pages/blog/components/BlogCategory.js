import React from 'react';
import { Styles } from '../styles/blogCategory.js';

const BlogCategory = () => {
    return (
        <Styles>
            {/* Blog Category */}
            <div className="blog-category">
                <h6>Categories</h6>
                <ul className="list-unstyled">
                    <li><a href="/">House Cleaning</a></li>
                    <li><a href="/">Office Cleaning</a></li>
                    <li><a href="/">Carpet Cleaning</a></li>
                    <li><a href="/">Window Cleaning</a></li>
                    <li><a href="/">Indoor Cleaning</a></li>
                    <li><a href="/">Outndoor Cleaning</a></li>
                </ul>
            </div>
        </Styles>
    )
}

export default BlogCategory