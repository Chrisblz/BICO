import React from 'react';
import { Link } from 'react-router-dom';
import { Styles } from '../styles/blogTag.js';

const BlogTag = () => {
    return (
        <Styles>
            {/* Blog Tag */}
            <div className="blog-tag">
                <h6>Blog Tag</h6>
                <div className="tag-box">
                    <Link to={process.env.PUBLIC_URL + "/"}>HTML</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>CSS</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Jquery</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Photoshop</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Javascript</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Laravel</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Wordpress</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>Bootstrap 5</Link>
                    <Link to={process.env.PUBLIC_URL + "/"}>React Js</Link>
                </div>
            </div>
        </Styles>
    )
}

export default BlogTag