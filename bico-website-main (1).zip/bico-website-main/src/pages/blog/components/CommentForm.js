import React from 'react';
import ReactFormValidation from "react-form-input-validation";
import { Row, Col } from 'react-bootstrap';
import { Styles } from '../styles/commentForm.js';

class CommentForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: {
                message: "",
                full_name: "",
                email: ""
            },
            errors: {}
        };

        this.form = new ReactFormValidation(this, { locale: "en" });

        this.form.useRules({
            message: "required|max:200",
            full_name: "required",
            email: "required|email"

        });
    }

    render() {
        return (
            <Styles>
                {/* Comment Form */}
                <div className="blog-comment-form">
                    <h5>Leave a comment</h5>
                    <form className="comment-form" noValidate autoComplete="off" onSubmit={this.form.handleSubmit}>
                        <Row>
                            <Col md="12">
                                <p className="form-box">
                                    <textarea
                                        name="message"
                                        maxLength="200"
                                        className="form-control"
                                        value={this.state.fields.message}
                                        onChange={this.form.handleChangeEvent}
                                        onBlur={this.form.handleBlurEvent}
                                        placeholder="Message"
                                    ></textarea>
                                    <label className="error">{this.state.errors.message ? this.state.errors.message : ""}</label>
                                </p>
                            </Col>
                            <Col md="6">
                                <p className="form-box">
                                    <input
                                        type="text"
                                        name="full_name"
                                        className="form-control"
                                        onBlur={this.form.handleBlurEvent}
                                        onChange={this.form.handleChangeEvent}
                                        value={this.state.fields.full_name}
                                        placeholder="First Name"
                                        data-attribute-name="Full Name"
                                        data-async
                                    />
                                    <label className="error">{this.state.errors.full_name ? this.state.errors.full_name : ""}</label>
                                </p>
                            </Col>
                            <Col md="6">
                                <p className="form-box">
                                    <input
                                        type="text"
                                        name="email"
                                        className="form-control"
                                        onBlur={this.form.handleBlurEvent}
                                        onChange={this.form.handleChangeEvent}
                                        value={this.state.fields.email}
                                        placeholder="Email Address"
                                        data-attribute-name="Email Address"
                                        data-async
                                    />
                                    <label className="error">{this.state.errors.email ? this.state.errors.email : ""}</label>
                                </p>
                            </Col>
                            <Col md="12">
                                <button type="submit">Post Comment</button>
                            </Col>
                        </Row>
                    </form>
                </div>
            </Styles>
        )
    }
}

export default CommentForm