import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .banner-area {
        .banner-box {
            background : ${colors.black1};
            padding : 50px 60px;
            border-radius: 25px;
            position: absolute;
            width: calc(100% - 30px);
            top: -30px;
            left: 15px;
            .banner-text {
                p {
                    font-size: 30px;
                    font-weight: 600;
                    color : #ffffff;
                    max-width: 440px;
                    line-height: 35px;
                    span {
                        color : ${colors.blue};
                        font-style: italic;
                    }

                    @media only screen and (max-width: 767px) {
                        font-size: 24px;
                    }
                }
            }
            .banner-btn {
                button.bn_btn {
                    color: #fff;
                    background-color: ${colors.red};
                    border: none;
                    font-size: 18px;
                    font-weight: 500;
                    border-radius: 0 25px;
                    width: 190px;
                    height: 50px;
                    margin-top: 10px;
                    &:hover {
                        background-color: ${colors.blue};
                    }

                    @media only screen and (max-width: 767px) {
                        font-size: 16px;
                        width: 150px;
                        height: 45px;
                    }
                }
            }

            @media only screen and (max-width: 991px) {
                padding: 30px 35px;
            }

            @media only screen and (max-width: 575px) {
                display: block !important;
                text-align: center;
            }
        }
    }
`;