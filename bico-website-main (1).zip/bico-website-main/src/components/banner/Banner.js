import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/banner.js";

const Banner = () => {
    return (
        <Styles>
            {/* Banner Area */}
            <section className="banner-area">
                <Container>
                    <Row>
                        <Col md="12">
                            <div className="banner-box d-flex justify-content-between">
                                <div className="banner-text">
                                    <p>Book Our Laundry Service & Get <span>30%</span> Discount</p>
                                </div>
                                <div className="banner-btn">
                                    <button type="button" className="bn_btn">Order Service</button>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </Styles>
    )
}

export default Banner