import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Dropdown } from 'react-bootstrap';
import PopupModal from '../common/PopupModal';
import Search from '../common/Search';
import Sidebar from '../common/Sidebar';
import StickyMenu from '../common/StickyMenu';
import MobileMenu from './../common/MobileMenu';
import { Styles } from "./styles/headerTwo.js";

const HeaderTwo = () => {
    return (
        <Styles>
            {/* Topbar */}
            <section className="topbar-two">
                <Container>
                    <Row>
                        <Col lg="8" md="10">
                            <div className="bar-left">
                                <ul className="list-unstyled list-inline">
                                    <li className="list-inline-item"><i className="las la-phone"></i>(908) 875 7678</li>
                                    <li className="list-inline-item"><i className="las la-envelope"></i>enquery@domain.com</li>
                                    <li className="list-inline-item"><i className="las la-map-marker"></i>795 South Park Avenue, CA</li>
                                </ul>
                            </div>
                        </Col>
                        <Col lg="4" md="2">
                            <div className="bar-right d-flex justify-content-end">
                                <ul className="list-unstyled list-inline social">
                                    <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                    <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                    <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                    <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                </ul>
                                <div className="cleaner-booking">
                                    <PopupModal />
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* Logo Area */}
            <section className="logo2-area">
                <Container>
                    <Row>
                        <Col md="12">
                            <div className="logo2-area-box">
                                <Row>
                                    <Col md="3">
                                        <div className="logo">
                                            <Link to={process.env.PUBLIC_URL + "/"}><img src={process.env.PUBLIC_URL + "/assets/images/f-logo.png"} alt="" /></Link>
                                        </div>
                                    </Col>
                                    <Col md="9">
                                        <div className="menu-box d-flex justify-content-end">
                                            <ul className="nav menu-nav">
                                                <li className="nav-item dropdown active">
                                                    <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Home <i className="las la-angle-down"></i></Link>
                                                    <ul className="dropdown list-unstyled">
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/"}>Home Style 1</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/home-two"}>Home Style 2</Link></li>
                                                    </ul>
                                                </li>
                                                <li className="nav-item dropdown">
                                                    <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Pages <i className="las la-angle-down"></i></Link>
                                                    <ul className="dropdown list-unstyled">
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/about"}>About Us</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/appointment"}>Appointment</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/faq"}>Faq</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/error"}>404</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/coming-soon"}>Coming Soon</Link></li>
                                                    </ul>
                                                </li>
                                                <li className="nav-item dropdown">
                                                    <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Service <i className="las la-angle-down"></i></Link>
                                                    <ul className="dropdown list-unstyled">
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-one"}>Service Style 1</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-two"}>Service Style 2</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-details"}>Service Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li className="nav-item dropdown">
                                                    <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Project <i className="las la-angle-down"></i></Link>
                                                    <ul className="dropdown list-unstyled">
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-one"}>Project Style 1</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-two"}>Project Style 2</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-details"}>Project Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li className="nav-item dropdown">
                                                    <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Blog <i className="las la-angle-down"></i></Link>
                                                    <ul className="dropdown list-unstyled">
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-classic"}>Blog Classic</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-grid"}>Blog Grid</Link></li>
                                                        <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-details"}>Blog Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/contact"}>Contact</Link></li>
                                            </ul>
                                            <div className="lang-box">
                                                <Dropdown>
                                                    <Dropdown.Toggle as="a"><img src={process.env.PUBLIC_URL + "/assets/images/us.png"} alt="" />Eng<i className="las la-angle-down"></i></Dropdown.Toggle>
                                                    <Dropdown.Menu as="ul">
                                                        <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/us.png"} alt="" /> Eng</Dropdown.Item>
                                                        <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/fra.png"} alt="" /> Fre</Dropdown.Item>
                                                        <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/ger.png"} alt="" /> Ger</Dropdown.Item>
                                                        <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/spa.png"} alt="" /> Spa</Dropdown.Item>
                                                        <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/bra.png"} alt="" /> Bra</Dropdown.Item>
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                            </div>
                                            <div className="search-box">
                                                <Search />
                                            </div>
                                            <div className="side-box">
                                                <Sidebar />
                                            </div>
                                        </div>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* Sticky Menu */}
            <StickyMenu />

            {/* Mobile Menu */}
            <MobileMenu />
        </Styles>
    )
}

export default HeaderTwo