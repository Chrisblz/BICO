import React from 'react';
import TextSlider from './TextSlider';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Dropdown } from 'react-bootstrap';
import Search from '../common/Search';
import Sidebar from '../common/Sidebar';
import PopupModal from '../common/PopupModal';
import StickyMenu from '../common/StickyMenu';
import MobileMenu from '../common/MobileMenu';
import { Styles } from "./styles/header.js";

const Header = () => {
    return (
        <Styles>
            {/* Topbar */}
            <section className="top-bar">
                <Container>
                    <Row>
                        <Col lg="5" md="6">
                            <TextSlider />
                        </Col>
                        <Col lg="7" md="6">
                            <div className="topbar-right d-flex justify-content-end">
                                <div className="topbar-menu text-right">
                                    <ul className="list-unstyled list-inline">
                                        <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/"}>Support</Link></li>
                                        <li className="list-inline-item"><Link to={process.env.PUBLIC_URL + "/contact"}>Contact Us</Link></li>
                                    </ul>
                                </div>
                                <div className="lag-box">
                                    <Dropdown>
                                        <Dropdown.Toggle as="a"><img src={process.env.PUBLIC_URL + "/assets/images/us.png"} alt="" />Eng<i className="las la-angle-down"></i></Dropdown.Toggle>
                                        <Dropdown.Menu as="ul">
                                            <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/us.png"} alt="" /> Eng</Dropdown.Item>
                                            <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/fra.png"} alt="" /> Fre</Dropdown.Item>
                                            <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/ger.png"} alt="" /> Ger</Dropdown.Item>
                                            <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/spa.png"} alt="" /> Spa</Dropdown.Item>
                                            <Dropdown.Item as="li"><img src={process.env.PUBLIC_URL + "/assets/images/bra.png"} alt="" /> Bra</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </div>
                                <div className="topbar-social">
                                    <ul className="list-unstyled list-inline bar-social">
                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                        <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* Logo Area */}
            <section className="logo-area">
                <Container>
                    <Row>
                        <Col xl="3" md="2">
                            <div className="logo">
                                <Link to={process.env.PUBLIC_URL + "/"}><img src={process.env.PUBLIC_URL + "/assets/images/logo.png"} alt="" /></Link>
                            </div>
                        </Col>
                        <Col xl="9" md="10">
                            <div className="logo-icon-box d-flex justify-content-end">
                                <div className="icon-box d-flex">
                                    <div className="box-icon">
                                        <i className="flaticon-phone-call"></i>
                                    </div>
                                    <div className="box-text">
                                        <p>Phone Number</p>
                                        <span>(908) 875 7678</span>
                                    </div>
                                </div>
                                <div className="icon-box d-flex">
                                    <div className="box-icon">
                                        <i className="flaticon-envelope"></i>
                                    </div>
                                    <div className="box-text">
                                        <p>Email Address</p>
                                        <span>enquary@domain.com</span>
                                    </div>
                                </div>
                                <div className="icon-box d-flex">
                                    <div className="box-icon">
                                        <i className="flaticon-location"></i>
                                    </div>
                                    <div className="box-text">
                                        <p>Our Location</p>
                                        <span>795 South Park Avenue, CA</span>
                                    </div>
                                </div>
                                <div className="search-box">
                                    <Search />
                                </div>
                                <div className="side-box">
                                    <Sidebar />
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* Menu Area */}
            <section className="main-menu-area">
                <Container>
                    <div className="menu-border">
                        <Row>
                            <Col md="12">
                                <div className="main-menu">
                                    <div className="menu-box d-flex justify-content-between">
                                        <ul className="nav menu-nav">
                                            <li className="nav-item dropdown active">
                                                <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Home <i className="las la-angle-down"></i></Link>
                                                <ul className="dropdown list-unstyled">
                                                    <li className="nav-item active"><Link className="nav-link" to={process.env.PUBLIC_URL + "/"}>Home Style 1</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/home-two"}>Home Style 2</Link></li>
                                                </ul>
                                            </li>
                                            <li className="nav-item dropdown">
                                                <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Pages <i className="las la-angle-down"></i></Link>
                                                <ul className="dropdown list-unstyled">
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/about"}>About Us</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/appointment"}>Appointment</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/faq"}>Faq</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/error"}>404</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/coming-soon"}>Coming Soon</Link></li>
                                                </ul>
                                            </li>
                                            <li className="nav-item dropdown">
                                                <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Service <i className="las la-angle-down"></i></Link>
                                                <ul className="dropdown list-unstyled">
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-one"}>Service Style 1</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-two"}>Service Style 2</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/service-details"}>Service Details</Link></li>
                                                </ul>
                                            </li>
                                            <li className="nav-item dropdown">
                                                <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Project <i className="las la-angle-down"></i></Link>
                                                <ul className="dropdown list-unstyled">
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-one"}>Project Style 1</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-two"}>Project Style 2</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/project-details"}>Project Details</Link></li>
                                                </ul>
                                            </li>
                                            <li className="nav-item dropdown">
                                                <Link className="nav-link dropdown-toggle" to={process.env.PUBLIC_URL + "/"} data-toggle="dropdown">Blog <i className="las la-angle-down"></i></Link>
                                                <ul className="dropdown list-unstyled">
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-classic"}>Blog Classic</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-grid"}>Blog Grid</Link></li>
                                                    <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/blog-details"}>Blog Details</Link></li>
                                                </ul>
                                            </li>
                                            <li className="nav-item"><Link className="nav-link" to={process.env.PUBLIC_URL + "/contact"}>Contact</Link></li>
                                        </ul>

                                        <div className="cleaner-booking">
                                            <PopupModal />
                                        </div>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </Container>
            </section>

            {/* Sticky Menu */}
            <StickyMenu />

            {/* Mobile Menu */}
            <MobileMenu />
        </Styles>
    )
}

export default Header