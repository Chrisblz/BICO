import React from 'react';
import { Tab, Nav } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Styles } from "./styles/tabBox.js";

class TabBox extends React.Component {
    render() {
        return (
            <Styles>
                {/* Tab Box Area */}
                <div className="tab-box">
                    <Tab.Container defaultActiveKey="confidence">
                        <Nav>
                            <Nav.Item>
                                <Nav.Link eventKey="confidence">Confidence</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="satisfaction">Satisfaction</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="expert">Expert Team</Nav.Link>
                            </Nav.Item>
                        </Nav>
                        <Tab.Content>
                            <Tab.Pane eventKey="confidence">
                                <div className="tab-desc">
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis voluptas consequatur dignissimos harum saepe iure rerum quod reiciendis ditos quos debitis.</p>
                                    <ul className="icon-box list-unstyled">
                                        <li><i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet consectet minixe iure rerum quod reiciendis kismhelore dimare tana.</li>
                                        <li><i className="las la-check-circle"></i>Obcaecati makam kisim maxime lopu namkin consectet minixe iure rerum vitae tempora.</li>
                                        <li><i className="las la-check-circle"></i>Quidem totam quas consec nostrum sapan rerum quod reiciendis ditos quos debitis iksim ipsa soqu.</li>
                                    </ul>
                                </div>
                                <div className="discover-btn d-flex">
                                    <div><Link to={process.env.PUBLIC_URL + "/"}>Discover More</Link></div>
                                    <div className="d-flex">
                                        <div className="phone-icon">
                                            <i className="las la-phone-volume"></i>
                                        </div>
                                        <div className="phone-number">
                                            <p>Call Us Anytime</p>
                                            <h5>(908) 875 7678</h5>
                                        </div>
                                    </div>
                                </div>
                            </Tab.Pane>
                            <Tab.Pane eventKey="satisfaction">
                                <div className="tab-desc">
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis voluptas consequatur dignissimos harum saepe iure rerum pussh quod reiciendis ditos quos debitis.</p>
                                    <ul className="icon-box list-unstyled">
                                        <li><i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet consectet minixe iure rerum quod reiciendis kismhelore dimare tana.</li>
                                        <li><i className="las la-check-circle"></i>Obcaecati makam kisim maxime lopu namkin consectet minixe iure rerum vitae tempora.</li>
                                        <li><i className="las la-check-circle"></i>Quidem totam quas consec nostrum sapan rerum quod reiciendis ditos quos debitis iksim ipsa soqu.</li>
                                    </ul>
                                </div>
                                <div className="discover-btn d-flex">
                                    <div><Link to={process.env.PUBLIC_URL + "/"}>Discover More</Link></div>
                                    <div className="d-flex">
                                        <div className="phone-icon">
                                            <i className="las la-phone-volume"></i>
                                        </div>
                                        <div className="phone-number">
                                            <p>Call Us Anytime</p>
                                            <h5>(908) 875 7678</h5>
                                        </div>
                                    </div>
                                </div>
                            </Tab.Pane>
                            <Tab.Pane eventKey="expert">
                                <div className="tab-desc">
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis voluptas consequatur dignissimos harum saepe iure kise linore rerum quod reiciendis ditos quos debitis.</p>
                                    <ul className="icon-box list-unstyled">
                                        <li><i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet consectet minixe iure rerum quod reiciendis kismhelore dimare tana.</li>
                                        <li><i className="las la-check-circle"></i>Obcaecati makam kisim maxime lopu namkin consectet minixe iure rerum vitae tempora.</li>
                                        <li><i className="las la-check-circle"></i>Quidem totam quas consec nostrum sapan rerum quod reiciendis ditos quos debitis iksim ipsa soqu.</li>
                                    </ul>
                                </div>
                                <div className="discover-btn d-flex">
                                    <div><Link to={process.env.PUBLIC_URL + "/"}>Discover More</Link></div>
                                    <div className="d-flex">
                                        <div className="phone-icon">
                                            <i className="las la-phone-volume"></i>
                                        </div>
                                        <div className="phone-number">
                                            <p>Call Us Anytime</p>
                                            <h5>(908) 875 7678</h5>
                                        </div>
                                    </div>
                                </div>
                            </Tab.Pane>
                        </Tab.Content>
                    </Tab.Container>
                </div>
            </Styles>
        )
    }
}

export default TabBox
