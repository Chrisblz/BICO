import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .tab-box {
        .nav {
            margin-bottom: 30px;
            .nav-item {
                margin-right: 15px;
                a.nav-link {
                    font-size    : 15px;
                    color        : ${colors.border1};
                    background: rgba(255,255,255,0.08);
                    padding      : 12px 25px;
                    border-radius: 0 25px;
                    text-transform: uppercase;

                    @media only screen and (max-width: 1199px) {
                        font-size: 14px;
                        padding: 10px 20px;
                    }

                    @media only screen and (max-width: 575px) {
                        padding: 10px 15px;
                    }
                }

                a.nav-link.active {
                    background: ${colors.red};
                    color     : #ffffff;

                    i {
                        color: #ffffff;
                    }
                }

                &:last-child {
                    a.nav-link {
                        border-bottom: none;
                    }
                }

                @media only screen and (max-width: 1199px) {
                    margin-right: 8px;
                }
            }
        }

        .tab-content {
            .tab-pane {
                .tab-desc {
                    p {
                        font-size: 15px;
                        color: ${colors.text4};
                        line-height: 28px;
                        margin-bottom: 30px;
                    }
                }

                ul.icon-box {
                    margin-bottom: 40px;
                    li {
                        font-size: 14px;
                        color: ${colors.text4};
                        line-height: 25px;
                        margin-bottom: 10px;
                        i {
                            font-size: 24px;
                            color: ${colors.blue};
                            margin-right: 8px;
                            float: left;
                            height: 35px;
                            transform: translateY(15%);
                        }
                        &:last-child {
                            margin-bottom: 0;
                        }
                    }
                }

                .discover-btn {
                    a {
                        color: #fff;
                        background-color: ${colors.blue};
                        font-size: 16px;
                        border-radius: 0 25px;
                        width: 170px;
                        height: 45px;
                        text-align: center;
                        display: inline-block;
                        padding-top: 11px;
                        margin-right: 30px;

                        &:hover {
                            background-color: ${colors.red};
                        }

                        @media only screen and (max-width: 575px) {
                            font-size: 14px;
                            width: 140px;
                            height: 42px;
                            margin-right: 10px;
                        }
                    }

                    i {
                        font-size: 24px;
                        color : ${colors.blue};
                        border : 1px solid ${colors.text2};
                        border-radius: 50%;
                        width: 45px;
                        height: 45px;
                        text-align: center;
                        padding-top: 11px;
                        margin-right: 8px;
                    }
                    p {
                        font-size: 14px;
                        color: ${colors.text3};
                        font-weight: 500;
                    }
                    h5 {
                        color: ${colors.border1};
                        font-weight: 400;
                    }
                }
            }
        }
    }
`;