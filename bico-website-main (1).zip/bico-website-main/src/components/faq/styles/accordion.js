import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .accordion-box {
        .accordion-item {
            margin-bottom: 12px;
            .accordion-header {
                margin-bottom: 15px;
                box-shadow: rgba(0,0,0,0.06) 0px 8px 20px;
                padding: 19px 25px;
                border-radius: 15px;
                cursor: pointer;
                position: relative;

                p {
                    font-size  : 16px;
                    color      : ${colors.black2};
                    font-weight: 600;
                    line-height: 18px;
                }

                .accordion-indicator {
                    i {
                        font-size : 16px;
                        color : ${colors.blue};
                        position : absolute;
                        right: 20px;
                        top: 22px;
                    }
                }
            }

            .accordion-body {
                background-color : ${colors.bg1};
                border-radius: 15px;

                p {
                    font-size   : 15px;
                    color       : ${colors.text2};
                    line-height : 28px;
                    padding: 13px 25px;
                }
            }

            &:last-child {
                margin-bottom : 0;
            }
        }

        @media only screen and (max-width: 767px) {
            margin-bottom: 40px;
        }
    }
`;