import React, { useState } from 'react';

const AccordionItem = ({ title, body }) => {
    const [isOpen, setIsOpen] = useState(true);

    return (
        <div className="accordion-item">
            <div className="accordion-header" onClick={() => setIsOpen(!isOpen)}>
                <p>{title}</p>
                <div className="accordion-indicator">
                    {isOpen ? <i className="las la-angle-up"></i> : <i className="las la-angle-down"></i>}
                </div>
            </div>
            {isOpen && (
                <div className="accordion-body">
                    <p>{body}</p>
                </div>
            )}
        </div>
    )
}

export default AccordionItem