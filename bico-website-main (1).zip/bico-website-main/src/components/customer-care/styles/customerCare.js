import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .customer-care {
        background: ${colors.black1};
        height: 200px;
        .care-text {
            padding-top: 60px;
            p {
                font-size: 30px;
                font-weight: 600;
                color: #ffffff;
                line-height: 35px;

                @media only screen and (max-width: 991px) {
                    font-size: 22px;
                }

                @media only screen and (max-width: 767px) {
                    margin-bottom: 20px;
                }
            }

            @media only screen and (max-width: 767px) {
                padding-top: 0;
                text-align: center;
            }
        }

        .care-contact {
            padding-top: 75px;
            i {
                font-size: 48px;
                color: ${colors.blue};
                margin-right: 12px;
            }
            span {
                color: ${colors.border3};
            }
            p {
                font-size: 30px;
                color: ${colors.red};
                margin-top: -7px;
                font-weight: 600;
            }

            @media only screen and (max-width: 767px) {
                padding-top: 0;
                justify-content: center !important;
            }
        }

        .care-img {
            height: 200px;
            position: relative;
            img {
                position: absolute;
                max-width: 70%;
                bottom: 0;
                right: 0;
                z-index: 1;
            }

            @media only screen and (max-width: 991px) {
                display: none;
            }
        }

        @media only screen and (max-width: 767px) {
            height: auto;
            padding: 50px 0;
        }

        @media only screen and (max-width: 575px) {
            padding: 30px 0 35px;
        }
    }
`;