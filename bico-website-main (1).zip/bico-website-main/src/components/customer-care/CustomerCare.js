import React from 'react';
import Datas from '../../data/care/customer-care.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/customerCare.js";

const CustomerCare = () => {
    return (
        <Styles>
            {/* Call Center */}
            <section className="customer-care">
                <Container>
                    <Row>
                        <Col md="6">
                            <div className="care-text">
                                <p>Need your home clean with a cleaning expert</p>
                            </div>
                        </Col>
                        <Col lg="3" md="6">
                            <div className="care-contact d-flex justify-content-end">
                                <div>
                                    <i className="fas fa-mobile-alt"></i>
                                </div>
                                <div>
                                    <span>Call Us Anytime</span>
                                    <p>514 901 937</p>
                                </div>
                            </div>
                        </Col>
                        <Col lg="3" md="0">
                            <div className="care-img">
                                <img src={process.env.PUBLIC_URL + `/assets/images/${Datas.imgUrl}`} alt="" className="img-fluid" />
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </Styles>
    )
}

export default CustomerCare