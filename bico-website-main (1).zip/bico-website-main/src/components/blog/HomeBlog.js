import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/blog/home-blog.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Styles } from "./styles/homeBlog.js";

class HomeBlog extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Blog Area */}
                <div className="home-blog-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <SecTitle
                                    title={this.state.Data.secTitle}
                                    subTitle={this.state.Data.secHeading}
                                />
                            </Col>

                            {
                                this.state.Data.dataList.map((data, i) => (
                                    <Col md="4" sm="6" key={i}>
                                        <div className="blog-box">
                                            <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} alt="" className="img-fluid blog-img" />
                                            <div className="blog-text">
                                                <span className="blog-tag">{data.postTag}</span>
                                                <h5 className="blog-title"><Link to={process.env.PUBLIC_URL + data.postLink}>{data.postTitle}</Link></h5>
                                                <div className="d-flex justify-content-between">
                                                    <div className="author">
                                                        <img src={process.env.PUBLIC_URL + `/assets/images/${data.authorImg}`} alt="" />
                                                        <p>{data.authorName}</p>
                                                    </div>
                                                    <div className="date">
                                                        <p>{data.postDate}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                ))
                            }
                        </Row>
                    </Container>
                </div>
            </Styles >
        )
    }
}

export default HomeBlog