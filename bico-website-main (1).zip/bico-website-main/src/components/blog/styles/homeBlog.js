import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .home-blog-area {
        padding : 65px 0 70px;

        .blog-box {
            position: relative;
            img.blog-img {
                border-radius: 25px;
            }
            .blog-text {
                position: absolute;
                bottom: 18px;
                left: 18px;
                background: #ffffff;
                width: 90%;
                padding: 20px 22px;
                border-radius: 15px;
                span.blog-tag {
                    display: inline-block;
                    font-size: 15px;
                    color: ${colors.red};
                    text-transform: capitalize;
                    font-weight: 500;
                    margin-bottom: 8px;

                    @media only screen and (max-width: 991px) {
                        font-size: 14px;
                        margin-bottom: 3px;
                    }
                }
                h5.blog-title {
                    border-bottom: 1px solid ${colors.border1};
                    padding-bottom: 10px;
                    margin-bottom: 15px;
                    a {
                        font-size: 18px;
                        color: ${colors.black1};
                        font-weight: 600;
                        &:hover {
                            color: ${colors.blue};
                        }

                        @media only screen and (max-width: 991px) {
                            font-size: 16px;
                        }
                    }
                }
                .author {
                    img {
                        width: 32px;
                        border-radius: 0 50%;
                        float: left;
                        margin-right: 10px;
                    }
                    p {
                        float: left;
                        color: ${colors.text3};
                        font-weight: 500;
                        transform: translateY(30%);
                    }
                }
                .date {
                    p {
                        color: ${colors.text3};
                        font-weight: 500;
                        margin-top: 6px;
                    }
                }

                @media only screen and (max-width: 991px) {
                    bottom: 12px;
                    left: 10px;
                    padding: 10px 15px;
                }

                @media only screen and (max-width: 575px) {
                    bottom: 4%;
                    left: 5%;
                }
            }

            @media only screen and (max-width: 767px) {
                margin-bottom: 30px;
            }
        }

        @media only screen and (max-width: 767px) {
            padding: 65px 0 45px;
        }

        @media only screen and (max-width: 575px) {
            padding: 40px 0 20px;
        }
    }
`;