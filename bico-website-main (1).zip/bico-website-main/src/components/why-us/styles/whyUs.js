import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .why-us-area {
        background: ${colors.black1};
        position: relative;
        overflow: hidden;
        .why-us-img {
            max-width: 50%;
            position: absolute;
            z-index: 111;
            img {
                max-height: 745px;
            }
            .icon-box {
                position: absolute;
                bottom: 25%;
                left: 10%;
                background-color: ${colors.red};
                max-width: 370px;
                border-radius: 15px;
                padding: 30px 20px;
                .box-icon {
                    i {
                        font-size: 56px;
                        color: #ffffff;
                        margin-right: 10px;
                    }
                }
                .icon-content {
                    p {
                        font-size: 16px;
                        color: #ffffff;
                        font-weight: 500;
                        margin-bottom: 6px;
                    }
                    a {
                        font-size: 14px;
                        color: ${colors.border1};
                        text-decoration: underline;
                        &:hover {
                            color: ${colors.blue};
                        }
                    }
                }
                &:before {
                    position: absolute;
                    content: "";
                    background: ${colors.red};
                    width: 20px;
                    height: 20px;
                    bottom: -10px;
                    left: 30px;
                    transform: rotate(45deg);
                }
            }

            @media only screen and (max-width: 991px) {
                display: none;
            }
        }
        .why-us-content {
            background: ${colors.black1};
            position: relative;
            &:before {
                position: absolute;
                content: "";
                background: ${colors.black1};
                width: 500px;
                height: 500px;
                top: -188px;
                left: -190px;
                z-index: 111;
                transform: rotate(-35deg);

                @media only screen and (max-width: 991px) {
                    content: none;
                }
            }
            &:after {
                position: absolute;
                content: "";
                background: ${colors.black1};
                width: 500px;
                height: 500px;
                bottom: -188px;
                left: -190px;
                z-index: 111;
                transform: rotate(35deg);

                @media only screen and (max-width: 991px) {
                    content: none;
                }
            }
            .content-box {
                position: relative;
                background: ${colors.black1};
                padding: 68px 0 73px;
                padding-left: 40px;
                z-index: 999;
                .about-title {
                    p {
                        font-size: 16px;
                        color: ${colors.blue};
                        font-weight: 500;
                        text-transform: uppercase;
                        margin-bottom: 5px;
                    }
                }
                .about-subtitle {
                    h3 {
                        color: ${colors.border3};
                        line-height: 35px;
                        font-weight: 700;
                        margin-bottom: 60px;
                        position: relative;
                        &:before {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -20px;
                            left: 0;
                        }
                        &:after {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -18px;
                            left: 0;
                        }
                    }
                }

                @media only screen and (max-width: 991px) {
                    padding-left: 0;
                }

                @media only screen and (max-width: 575px) {
                    padding: 40px 0 50px;
                }
            }
        }
    }
`;