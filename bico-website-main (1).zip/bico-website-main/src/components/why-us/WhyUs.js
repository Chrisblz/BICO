import React from 'react';
import Datas from '../../data/why-us/why-us.json';
import { Container, Row, Col } from 'react-bootstrap';
import TabBox from '../tab-box/TabBox';
import { Link } from 'react-router-dom';
import { Styles } from "./styles/whyUs.js";

class WhyUs extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Service Area */}
                <section className="why-us-area">
                    <div className="why-us-img">
                        <img src={process.env.PUBLIC_URL + `/assets/images/${this.state.Data.imgUrl}`} alt="" />
                        <div className="icon-box d-flex">
                            <div className="box-icon">
                                <i className="las la-certificate"></i>
                            </div>
                            <div className="icon-content">
                                <p>Trixol is Certified and Trusted Cleaning Service Company.</p>
                                <Link to={process.env.PUBLIC_URL + "/"}>Get Started</Link>
                            </div>
                        </div>
                    </div>
                    <Container>
                        <Row className="margin-fix">
                            <Col lg={{ span: 6, offset: 6 }} md="12" className="padding-fix">
                                <div className="why-us-content">
                                    <Col md="12" className="padding-fix">
                                        <div className="content-box">
                                            <div className="about-title">
                                                <p>{this.state.Data.secTitle}</p>
                                            </div>
                                            <div className="about-subtitle">
                                                <h3>{this.state.Data.secSubtitle}</h3>
                                            </div>

                                            {/* Tab Box Area */}
                                            <TabBox />
                                        </div>
                                    </Col>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
            </Styles>
        )
    }
}

export default WhyUs