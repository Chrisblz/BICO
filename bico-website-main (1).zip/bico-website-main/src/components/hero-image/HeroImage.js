import React from 'react';
import Datas from '../../data/hero/hero-image.json';
import { Link } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import ModalVideo from 'react-modal-video';
import 'react-modal-video/css/modal-video.min.css';
import { Styles } from "./styles/heroImage.js";

class HeroImage extends React.Component {
    constructor() {
        super()
        this.state = {
            isOpen: false,
            Data: Datas
        }
        this.openModal = this.openModal.bind(this)
    }

    openModal() {
        this.setState({ isOpen: true })
    }

    render() {
        return (
            <Styles>
                {/* Hero Image */}
                < section className="hero-image-area" style={{ backgroundImage: `url(${process.env.PUBLIC_URL}/assets/images/${this.state.Data.heroBackground})` }}>
                    <div className="hero-table">
                        <div className="hero-tablecell">
                            <Container>
                                <Row>
                                    <Col md="12">
                                        <div className="hero-box">
                                            <div className="hero-heading">
                                                <p>{this.state.Data.heading}</p>
                                            </div>
                                            <div className="hero-title">
                                                <h1>{this.state.Data.title}</h1>
                                            </div>
                                            <div className="hero-desc">
                                                <p>{this.state.Data.desc}</p>
                                            </div>
                                            <div className="hero-btn">
                                                <Link className="hero-btn" to={process.env.PUBLIC_URL + `/${this.state.Data.btnLink}`}>About Us<i className="las la-arrow-circle-right"></i></Link>
                                                <ModalVideo channel='youtube' isOpen={this.state.isOpen} videoId={this.state.videoLink} onClose={() => this.setState({ isOpen: false })} />
                                                <button className="play-button" onClick={this.openModal}><i className="las la-play"></i><span>Watch Online</span></button>
                                            </div>
                                        </div>
                                    </Col>
                                </Row>
                            </Container>
                        </div>
                    </div>
                </section >
            </Styles >
        )
    }
}

export default HeroImage