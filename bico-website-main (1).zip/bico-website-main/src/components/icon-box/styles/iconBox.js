import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .icon-box-area {
        position: relative;
        .icon-boxes {
            background: #ffffff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: rgba(0, 0, 0, 0.07) 0px 12px 25px;
            position: absolute;
            width: calc(100% - 30px);
            height: 110px;
            top: -35px;
            left: 15px;
            .icon-box {
                .box-icon {
                    i {
                        font-size: 30px;
                        color: ${colors.blue};
                        margin-right: 12px;

                        @media only screen and (max-width: 1199px) {
                            font-size: 26px;
                            margin-right: 4px;
                        }
                    }
                }
                .icon-info {
                    h6 {
                        color: ${colors.black1};
                        text-transform: uppercase;
                        font-weight: 600;
                        margin-bottom: 6px;

                        @media only screen and (max-width: 1199px) {
                            font-size: 14px;
                            margin-bottom: 3px;
                            letter-spacing: 0;
                        }
                    }
                    p {
                        color: ${colors.text3};
                    }
                }
            }

            @media only screen and (max-width: 1199px) {
                padding: 10px;
                height: 95px;
            }
        }

        .call-box {
            background: ${colors.black1};
            padding: 28px 25px 25px;
            border-radius: 15px;
            box-shadow: rgba(0, 0, 0, 0.07) 0px 12px 25px;
            position: absolute;
            width: calc(100% - 30px);
            height: 110px;
            top: -35px;
            left: 15px;
            i {
                font-size: 52px;
                color: ${colors.blue};
                margin-right: 12px;

                @media only screen and (max-width: 1199px) {
                    font-size: 26px;
                    margin-right: 5px;
                    transform: translateY(30%);
                }
            }
            span {
                color: ${colors.border3};
            }
            p {
                font-size: 28px;
                color: ${colors.red};
                margin-top: -4px;
                font-weight: 600;

                @media only screen and (max-width: 1199px) {
                    font-size: 20px;
                    margin-top: 0;
                }

                @media only screen and (max-width: 1199px) {
                    font-size: 18px;
                }
            }

            @media only screen and (max-width: 1199px) {
                padding: 25px 10px;
                height: 95px;
            }
        }

        @media only screen and (max-width: 767px) {
            display: none;
        }
    }
`;