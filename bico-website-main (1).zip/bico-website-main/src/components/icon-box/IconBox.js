import React from 'react';
import Datas from '../../data/icon-box/icon-box.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/iconBox.js";

class IconBox extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Icon Box Area */}
                <section className="icon-box-area">
                    <Container>
                        <Row>
                            <Col md="9">
                                <div className="icon-boxes">
                                    <Row>
                                        {
                                            this.state.Data.map((data, i) => (
                                                <Col md="4" key={i}>
                                                    <div className="icon-box d-flex">
                                                        <div className="box-icon">
                                                            <i className={data.boxIcon}></i>
                                                        </div>
                                                        <div className="icon-info">
                                                            <h6>{data.title}</h6>
                                                            <p>{data.subTitle}</p>
                                                        </div>
                                                    </div>
                                                </Col>
                                            ))
                                        }
                                    </Row>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="call-box d-flex">
                                    <div>
                                        <i className="fas fa-mobile-alt"></i>
                                    </div>
                                    <div>
                                        <span>Call Us Anytime</span>
                                        <p>514 901 937</p>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
            </Styles>
        )
    }
}

export default IconBox