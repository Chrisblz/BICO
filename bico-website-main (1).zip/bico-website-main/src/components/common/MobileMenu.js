import React from 'react';
import { Container, Row, Col, Accordion, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Search from './Search';
import { Styles } from "./styles/mobileMenu.js";

class MobileMenu extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            mobileBtn: false,
        }

        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(e) {
        e.preventDefault();
        this.setState((prevState) => {
            return {
                mobileBtn: !prevState.mobileBtn,
            }
        });
    }

    render() {
        let mobileMenuBody = (this.state.mobileBtn ? ' visible' : '');
        let mobileMenuOverlay = (this.state.mobileBtn ? ' active' : '');

        return (
            <Styles>
                {/* Mobile Menu */}
                <section className="mobile-menu-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <div className="mb-topbar d-flex justify-content-between">
                                    <div className="topbar-item">
                                        <p><i className="las la-phone"></i>+1 (396) 486 4709</p>
                                    </div>
                                    <div className="topbar-item">
                                        <ul className="list-unstyled list-inline mb-social">
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="mb-logo-area d-flex justify-content-between">
                                    <div className="mb-logo-box d-flex">
                                        <div className="mb-menu-btn">
                                            <a href={process.env.PUBLIC_URL + "/"} onClick={this.handleClick}>
                                                <i className="las la-bars"></i>
                                            </a>
                                        </div>
                                        <div className="mb-logo">
                                            <Link to={process.env.PUBLIC_URL + "/"}><img src={process.env.PUBLIC_URL + "/assets/images/f-logo.png"} alt="" /></Link>
                                        </div>
                                    </div>
                                    <div className="mb-search">
                                        <Search />
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>

                {/* Mobile Menu Sidebar */}
                <section className={`mb-sidebar${mobileMenuBody}`}>
                    <div className="mb-sidebar-heading d-flex justify-content-between">
                        <div><h5>Menu</h5></div>
                        <div><a href={process.env.PUBLIC_URL + "/"} onClick={this.handleClick}><i className="las la-times"></i></a></div>
                    </div>
                    <div className="mb-sidebar-menu">
                        <Accordion defaultActiveKey="page">
                            <Card>
                                <Accordion.Toggle as={Card.Header} eventKey="home">Home<i className="las la-plus"></i></Accordion.Toggle>
                                <Accordion.Collapse eventKey="home">
                                    <Card.Body>
                                        <ul className="list-unstyled">
                                            <li><Link to={process.env.PUBLIC_URL + "/"}>Home Style 1</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/home-two"}>Home Style 2</Link></li>
                                        </ul>
                                    </Card.Body>
                                </Accordion.Collapse>
                            </Card>
                            <Card>
                                <Accordion.Toggle as={Card.Header} eventKey="page">Pages<i className="las la-plus"></i></Accordion.Toggle>
                                <Accordion.Collapse eventKey="page">
                                    <Card.Body>
                                        <ul className="list-unstyled">
                                            <li><Link to={process.env.PUBLIC_URL + "/about"}>About Us</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/appointment"}>Appointment</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/faq"}>Faq</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/error"}>404</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/coming-soon"}>Coming Soon</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/contact"}>Contact</Link></li>
                                        </ul>
                                    </Card.Body>
                                </Accordion.Collapse>
                            </Card>
                            <Card>
                                <Accordion.Toggle as={Card.Header} eventKey="service">Service<i className="las la-plus"></i></Accordion.Toggle>
                                <Accordion.Collapse eventKey="service">
                                    <Card.Body>
                                        <ul className="list-unstyled">
                                            <li><Link to={process.env.PUBLIC_URL + "/service-one"}>Service Style 1</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/service-two"}>Service Style 2</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/service-details"}>Service Details</Link></li>
                                        </ul>
                                    </Card.Body>
                                </Accordion.Collapse>
                            </Card>
                            <Card>
                                <Accordion.Toggle as={Card.Header} eventKey="project">Project<i className="las la-plus"></i></Accordion.Toggle>
                                <Accordion.Collapse eventKey="project">
                                    <Card.Body>
                                        <ul className="list-unstyled">
                                            <li><Link to={process.env.PUBLIC_URL + "/project-one"}>Project Style 1</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/project-two"}>Project Style 2</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/project-details"}>Project Details</Link></li>
                                        </ul>
                                    </Card.Body>
                                </Accordion.Collapse>
                            </Card>
                            <Card>
                                <Accordion.Toggle as={Card.Header} eventKey="blog">Blog<i className="las la-plus"></i></Accordion.Toggle>
                                <Accordion.Collapse eventKey="blog">
                                    <Card.Body>
                                        <ul className="list-unstyled">
                                            <li><Link to={process.env.PUBLIC_URL + "/blog-classic"}>Blog Classic</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/blog-grid"}>Blog Grid</Link></li>
                                            <li><Link to={process.env.PUBLIC_URL + "/blog-details"}>Blog Details</Link></li>
                                        </ul>
                                    </Card.Body>
                                </Accordion.Collapse>
                            </Card>

                        </Accordion>
                    </div>
                </section>

                <div className={`mb-sidebar-overlay${mobileMenuOverlay}`} onClick={this.handleClick}></div>
            </Styles>
        )
    }
}

export default MobileMenu