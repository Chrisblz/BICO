import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/team/team-slider.json';
import { Container, Row, Col } from 'react-bootstrap';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import { Styles } from "./styles/teamSlider.js";

class TeamSlider extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        const settings = {
            dots: false,
            arrows: false,
            infinite: true,
            slidesToShow: 4,
            autoplay: false,
            speed: 700,
            autoplaySpeed: 3000,
            cssEase: "linear",
            pauseOnHover: true,
            responsive: [
                {
                    breakpoint: 1199,
                    settings: {
                        slidesToShow: 4,
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                    }
                },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 2,
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                    }
                }
            ]
        };

        return (
            <Styles>
                {/* Team Slider */}
                <section className="team-slider-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <SecTitle
                                    title={this.state.Data.secTitle}
                                    subTitle={this.state.Data.secHeading}
                                />
                            </Col>
                            <Col md="12">
                                <div className="team-slider">
                                    <Slider {...settings}>
                                        {
                                            this.state.Data.dataList.map((data, i) => (
                                                <div className="team-item" key={i}>
                                                    <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} alt="" className="img-fluid" />
                                                    <div className="img-content text-center">
                                                        <h5>{data.name}</h5>
                                                        <p>{data.title}</p>
                                                    </div>
                                                </div>
                                            ))
                                        }
                                    </Slider>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
            </Styles>
        )
    }
}

export default TeamSlider