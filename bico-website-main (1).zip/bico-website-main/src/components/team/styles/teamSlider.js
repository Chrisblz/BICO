import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .team-slider-area {
        background : ${colors.bg1};
        padding : 65px 0 150px;

        .team-slider {
            .slick-slider {
                .slick-list {
                    margin: 0 -15px;
                    .slick-slide {
                        padding: 0 15px;
                        .team-item {
                            border-radius: 20px;
                            overflow: hidden;
                            img {
                                
                            }
                            .img-content {
                                background : #ffffff;
                                padding: 10px 0 20px;
                                position: relative;
                                &:before {
                                    position: absolute;
                                    content: "";
                                    background: #ffffff;
                                    width: 50%;
                                    height: 38px;
                                    top: -18px;
                                    left: 0;
                                    transform: skewY(15deg);
                                }
                                &:after {
                                    position: absolute;
                                    content: "";
                                    background: #ffffff;
                                    width: 50%;
                                    height: 38px;
                                    top: -18px;
                                    right: 0;
                                    transform: skewY(-15deg);
                                }
                                h5 {
                                    position: relative;
                                    z-index: 1;
                                    color: ${colors.black1};
                                    font-weight: 600;
                                }
                                p {
                                    position: relative;
                                    z-index: 1;
                                    color: ${colors.text3};
                                }
                            }
                            
                            &:focus {
                                outline: none;
                            }
                        }
                    }
                }
            }
        }

        @media only screen and (max-width: 1199px) {
            padding: 65px 0 100px;
        }

        @media only screen and (max-width: 991px) {
            padding: 65px 0 70px;
        }

        @media only screen and (max-width: 575px) {
            padding: 35px 0 40px;
        }
    }
`;