import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .consultation-area {
        padding: 70px 0;
        .consult-box {
            background: ${colors.bg1};
            border-radius: 20px;
            overflow: hidden;
            .consult-img {
                img {
                    max-width: 400px;
                }

                @media only screen and (max-width: 991px) {
                    display: none;
                }
            }

            .consult-form {
                padding: 60px;

                .sec-title {
                    p {
                        font-size: 16px;
                        color : ${colors.blue};
                        font-weight : 500;
                        text-transform : uppercase;
                        margin-bottom: 5px;
                    }
                }
                .sec-subtitle {
                    h3 {
                        color : ${colors.black1};
                        line-height : 35px;
                        font-weight : 700;
                        margin-bottom: 40px;
                        position: relative;
                        &:before {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -20px;
                            left: 0;
                        }
                        &:after {
                            position: absolute;
                            content: "";
                            background: ${colors.blue};
                            width: 60px;
                            height: 1px;
                            bottom: -18px;
                            left: 0;
                        }
                    }
                }

                form.consult_form {
                    p.form-box {
                        padding   : 0;
                        width     : auto;
                        height    : auto;
                        background: transparent;
                        border    : none;
                        position  : relative;
                        margin-bottom: 20px;

                        input {
                            width           : 100%;
                            height          : 45px;
                            background-color: transparent;
                            font-size       : 15px;
                            padding         : 15px 0;
                            color           : ${colors.black2};
                            border          : none;
                            border-bottom : 2px solid ${colors.border3};
                            border-radius: 0;

                            &:focus {
                                color: ${colors.black1};
                                border-color: ${colors.blue};
                                box-shadow: none;

                                &::placeholder {
                                    color: ${colors.black1};
                                }
                            }

                            &::placeholder {
                                font-size  : 15px;
                                color      : ${colors.text2};
                            }
                        }

                        textarea {
                            width           : 100%;
                            height          : 130px;
                            background-color: transparent;
                            font-size       : 15px;
                            padding         : 15px 0;
                            color           : ${colors.black2};
                            border          : none;
                            border-bottom : 2px solid ${colors.border3};
                            border-radius: 0;

                            &:focus {
                                color           : ${colors.black1};
                                border-color: ${colors.blue};
                                box-shadow: none;

                                &::placeholder {
                                    color: ${colors.black1};
                                }
                            }

                            &::placeholder {
                                font-size  : 15px;
                                color      : ${colors.text2};
                            }
                        }

                        label.error {
                            font-size: 14px;
                            color: ${colors.red};
                            position: absolute;
                            top: 100%;
                            left: 0;
                            line-height: 20px;
                            letter-spacing: 0;
                        }

                        @media only screen and (max-width: 575px) {
                            padding-bottom: 15px;
                        }
                    }

                    button {
                        color: #fff;
                        background-color: ${colors.red};
                        font-size: 16px;
                        font-weight: 500;
                        border-radius: 0 30px;
                        width: 190px;
                        height: 48px;
                        padding-top: 3px;
                        text-align: center;
                        border: none;
                        display: inline-block;
                        margin-top: 15px;

                        &:hover {
                            background: ${colors.blue};
                        }
                    }
                }

                @media only screen and (max-width: 575px) {
                    padding: 30px;
                }
            }
        }

        @media only screen and (max-width: 575px) {
            padding: 40px 0;
        }
    }
`;