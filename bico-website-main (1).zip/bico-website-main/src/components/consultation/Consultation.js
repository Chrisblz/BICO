import React from 'react';
import ConsultForm from './ConsultForm';
import Datas from '../../data/consultation/consultation.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/consultation.js";

class Consultation extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Consultation Area */}
                < section className="consultation-area" >
                    <Container>
                        <Row>
                            <Col md="12">
                                <div className="consult-box d-flex">
                                    <div className="consult-img">
                                        <img src={process.env.PUBLIC_URL + `/assets/images/${this.state.Data.consultImage}`} alt="" className="img-fluid" />
                                    </div>
                                    <div className="consult-form">
                                        <div className="sec-title">
                                            <p>{this.state.Data.secTitle}</p>
                                        </div>
                                        <div className="sec-subtitle">
                                            <h3>{this.state.Data.secSubTitle}</h3>
                                        </div>

                                        {/* Consulting Form */}
                                        <ConsultForm />
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section >
            </Styles >
        )
    }
}

export default Consultation