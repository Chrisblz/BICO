import React from 'react';
import ReactFormValidation from "react-form-input-validation";
import { Row, Col } from 'react-bootstrap';

class ConsultForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: {
                full_name: "",
                email: "",
                phone: "",
                subject: "",
                message: ""
            },
            errors: {}
        };

        this.form = new ReactFormValidation(this, { locale: "en" });

        this.form.useRules({
            full_name: "required|full_name",
            email: "required|email",
            phone: "required|numeric",
            subject: "required",
            message: "required|max:200"
        });
    }

    render() {
        return (
            <form className="consult_form" noValidate autoComplete="off" onSubmit={this.form.handleSubmit}>
                <Row>
                    <Col md="6">
                        <p className="form-box">
                            <input
                                type="text"
                                name="full_name"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.full_name}
                                placeholder="First Name"
                                data-attribute-name="Full Name"
                                data-async
                            />
                            <label className="error">{this.state.errors.full_name ? this.state.errors.full_name : ""}</label>
                        </p>
                    </Col>
                    <Col md="6">
                        <p className="form-box">
                            <input
                                type="text"
                                name="email"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.email}
                                placeholder="Email Address"
                                data-attribute-name="Email Address"
                                data-async
                            />
                            <label className="error">{this.state.errors.email ? this.state.errors.email : ""}</label>
                        </p>
                    </Col>
                    <Col md="6">
                        <p className="form-box">
                            <input
                                type="text"
                                name="phone"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.phone}
                                placeholder="Phone Number"
                            />
                            <label className="error">{this.state.errors.phone ? this.state.errors.phone : ""}</label>
                        </p>
                    </Col>
                    <Col md="6">
                        <p className="form-box">
                            <input
                                type="text"
                                name="subject"
                                className="form-control"
                                onBlur={this.form.handleBlurEvent}
                                onChange={this.form.handleChangeEvent}
                                value={this.state.fields.subject}
                                placeholder="Subject"
                            />
                            <label className="error">{this.state.errors.subject ? this.state.errors.subject : ""}</label>
                        </p>
                    </Col>
                    <Col md="12">
                        <p className="form-box">
                            <textarea
                                name="message"
                                maxLength="200"
                                className="form-control"
                                value={this.state.fields.message}
                                onChange={this.form.handleChangeEvent}
                                onBlur={this.form.handleBlurEvent}
                                placeholder="Message"
                            ></textarea>
                            <label className="error">{this.state.errors.message ? this.state.errors.message : ""}</label>
                        </p>
                    </Col>
                    <Col md="12">
                        <button type="submit">Send Message</button>
                    </Col>
                </Row>
            </form>
        );
    }
}

export default ConsultForm;
