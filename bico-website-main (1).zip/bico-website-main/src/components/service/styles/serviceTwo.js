import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .service2-area {
        background : ${colors.bg1};
        padding : 65px 0 25px;

        .service-box {
            background : #ffffff;
            padding: 20px 25px;
            padding-left: 55px;
            border-radius: 0 45px;
            margin-bottom: 45px;
            margin-left: 9%;
            box-shadow: rgba(0, 0, 0, 0.05) 0px 10px 20px;
            transition: all 0.2s ease;
            position: relative;
            .box-icon {
                position: absolute;
                top: 20px;
                left: -10%;

                span {
                    background : ${colors.blue};
                    display: block;
                    width: 65px;
                    height: 65px;
                    text-align: center;
                    border-radius: 50%;
                    padding-top: 12px;
                    margin-right: 12px;
                    margin-top: 6px;
                    i {
                        font-size: 34px;
                        color: #ffffff;

                        @media only screen and (max-width: 575px) {
                            font-size: 30px;
                        }
                    }

                    @media only screen and (max-width: 575px) {
                        margin-top: -8px;
                    }
                }
            }
            .box-content {
                h5 {
                    color: ${colors.black1};
                    font-weight: 700;
                    margin-bottom: 5px;
                }
                p {
                    font-size : 14px;
                    color : ${colors.text3};
                    line-height: 25px;
                }
            }

            i.btm-arrow {
                position : absolute;
                bottom: 15px;
                right: 22px;
                font-size: 30px;
                color: ${colors.border3};
            }

            &:hover {
                box-shadow: rgba(0, 0, 0, 0.09) 0px 10px 20px;
                i.btm-arrow {
                    color: ${colors.red};
                }
            }

            @media only screen and (max-width: 1199px) {
                padding-left: 50px;
            }

            @media only screen and (max-width: 575px) {
                margin-bottom: 30px;
            }
        }

        @media only screen and (max-width: 575px) {
            padding: 40px 0 20px;
        }
    }
`;