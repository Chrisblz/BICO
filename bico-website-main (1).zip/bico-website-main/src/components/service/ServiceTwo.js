import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/service/service-two.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/serviceTwo.js";

class ServiceTwo extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* Service Area */}
                <section className="service2-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <SecTitle
                                    title={this.state.Data.secTitle}
                                    subTitle={this.state.Data.secHeading}
                                />
                            </Col>
                            {
                                this.state.Data.dataList.map((data, i) => (
                                    <Col lg="4" sm="6" key={i}>
                                        <div className="service-box">
                                            <div className="box-icon">
                                                <span><i className={data.icon}></i></span>
                                            </div>
                                            <div className="box-content">
                                                <h5>{data.title}</h5>
                                                <p>{data.desc}</p>
                                            </div>
                                            <i className="las la-long-arrow-alt-right btm-arrow"></i>
                                        </div>
                                    </Col>
                                ))
                            }
                        </Row>
                    </Container>
                </section>
            </Styles>
        )
    }
}

export default ServiceTwo