import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/service/service.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/service.js";

const Service = () => {
    return (
        <Styles>
            {/* Service Area */}
            <section className="service-area">
                <Container>
                    <Row>
                        <Col md="12">
                            <SecTitle
                                title={Datas.secTitle}
                                subTitle={Datas.secHeading}
                            />
                        </Col>
                        <Col lg="4" md="6">
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-laundry"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>Laundry Service</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-post-office"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>Office Cleaning</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-doorway"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>Indoor Cleaning</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                        </Col>
                        <Col lg="4" md="6">
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-house"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>House Cleaning</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-store"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>Shop Cleaning</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                            <div className="service-box d-flex">
                                <div className="box-icon">
                                    <span><i className="flaticon-mountains"></i></span>
                                </div>
                                <div className="box-content">
                                    <h5>Outdoor Cleaning</h5>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisic.</p>
                                </div>
                                <i className="las la-long-arrow-alt-right btm-arrow"></i>
                            </div>
                        </Col>
                        <Col lg="4" md="0">
                            <div className="service-image text-center">
                                <img src={process.env.PUBLIC_URL + `/assets/images/${Datas.serviceImg}`} className="img-fluid" alt="" />
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </Styles>
    )
}

export default Service