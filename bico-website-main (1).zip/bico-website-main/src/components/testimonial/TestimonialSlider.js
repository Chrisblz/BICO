import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/testimonial/slider.json';
import { Container, Row, Col } from 'react-bootstrap';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import { Styles } from "./styles/testimonialSlider.js";

class TestimonialSlider extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        const settings = {
            dots: false,
            arrows: false,
            infinite: true,
            slidesToShow: 1,
            autoplay: false,
            speed: 700,
            autoplaySpeed: 3000,
            cssEase: "linear",
            pauseOnHover: true,
        };

        return (
            <Styles>
                {/* Testimonial Area */}
                <div className="testimonial-area">
                    <Container>
                        <Row>
                            <Col md="12">
                                <SecTitle
                                    title={this.state.Data.secTitle}
                                    subTitle={this.state.Data.secHeading}
                                />
                            </Col>
                            <Col md="12" className="testimonial-slider">
                                <Slider {...settings}>
                                    {
                                        this.state.Data.dataList.map((data, i) => (
                                            <div className="slider-item" key={i}>
                                                <Row>
                                                    <Col md="4" sm="0">
                                                        <div className="slider-image">
                                                            <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} alt="" className="img-fluid" />
                                                        </div>

                                                    </Col>
                                                    <Col md="8" sm="12">
                                                        <div className="slider-content">
                                                            <p>{data.comment}</p>
                                                            <h5>{data.name}</h5>
                                                            <span>{data.title}</span>
                                                            <ul className="list-unstyled list-inline">
                                                                <li className="list-inline-item"><i className="las la-star"></i></li>
                                                                <li className="list-inline-item"><i className="las la-star"></i></li>
                                                                <li className="list-inline-item"><i className="las la-star"></i></li>
                                                                <li className="list-inline-item"><i className="las la-star"></i></li>
                                                                <li className="list-inline-item"><i className="las la-star"></i></li>
                                                            </ul>
                                                            <i className="flaticon-quotes-right"></i>
                                                        </div>
                                                    </Col>
                                                </Row>
                                            </div>
                                        ))
                                    }
                                </Slider>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </Styles >
        )
    }
}

export default TestimonialSlider