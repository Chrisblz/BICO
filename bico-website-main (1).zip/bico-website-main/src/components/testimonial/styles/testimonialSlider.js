import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .testimonial-area {
        background : ${colors.black1};
        padding : 65px 0 70px;
        .sec-title {
            p {
                font-size: 16px;
                color: ${colors.blue};
                font-weight: 500;
                text-transform: uppercase;
                margin-bottom: 5px;
            }
            h3 {
                color: ${colors.border3};
                line-height: 35px;
                font-weight: 700;
                max-width: 750px;
                margin : auto;
                margin-bottom: 60px;
                position: relative;
                &:before {
                    position: absolute;
                    content: "";
                    background: ${colors.blue};
                    width: 60px;
                    height: 1px;
                    bottom: -20px;
                    left: 50%;
                    margin-left: -30px;
                }
                &:after {
                    position: absolute;
                    content: "";
                    background: ${colors.blue};
                    width: 60px;
                    height: 1px;
                    bottom: -18px;
                    left: 50%;
                    margin-left: -30px;
                }
            }
        }

        .testimonial-slider {
            .slider-item {
                background: rgba(255, 255, 255, 0.08);
                height: 335px;
                padding: 0 50px;
                margin: 35px 0;
                border-radius : 25px;
                .slider-image {
                    position: relative;
                    img {
                        position: absolute;
                        top: -33px;
                        left: 0;
                        z-index: 1;
                        border-radius : 0 25px;

                        @media only screen and (max-width: 1199px) {
                            top: -27px;
                        }

                        @media only screen and (max-width: 991px) {
                            top: 25px;
                        }

                        @media only screen and (max-width: 767px) {
                            display: none;
                        }
                    }
                }
                .slider-content {
                    padding-top: 70px;
                    padding-left: 20px;
                    p {
                        font-size : 16px;
                        color : ${colors.text4};
                        line-height: 28px;
                        margin-bottom: 20px;

                        @media only screen and (max-width: 991px) {
                            font-size : 15px;
                        }
                    }
                    h5 {
                        color : ${colors.border1};
                        margin-bottom: 10px;
                    }
                    span {
                        font-size: 13px;
                        color : ${colors.red};
                        font-weight: 500;
                        display: inline-block;
                        margin-bottom: 12px;
                    }
                    ul {
                        li {
                            margin-right: 3px;
                            i {
                                font-size: 15px;
                                color : ${colors.yellow};
                            }
                        }
                    }
                    i.flaticon-quotes-right {
                        font-size: 46px;
                        color: ${colors.text2};
                        position: absolute;
                        bottom: -65px;
                        right: 0;

                        @media only screen and (max-width: 1199px) {
                            bottom: -30px;
                        }

                        @media only screen and (max-width: 991px) {
                            font-size: 36px;
                            bottom: -15px;
                        }
                    }

                    @media only screen and (max-width: 1199px) {
                        padding-top: 30px;
                        padding-left: 10px;
                    }

                    @media only screen and (max-width: 991px) {
                        padding-top: 17px;
                        padding-left: 0;
                    }

                    @media only screen and (max-width: 767px) {
                        padding-top: 0;
                    }
                }

                @media only screen and (max-width: 1199px) {
                    height: 280px;
                    padding: 0 40px;
                }

                @media only screen and (max-width: 767px) {
                    height: auto;
                    padding: 20px 30px;
                    margin: 0;
                }
            }
        }

        @media only screen and (max-width: 991px) {
            padding: 65px 0 40px;
        }

        @media only screen and (max-width: 767px) {
            padding: 65px 0 70px;
        }

        @media only screen and (max-width: 575px) {
            padding: 40px 0 45px;
        }
    }
`;