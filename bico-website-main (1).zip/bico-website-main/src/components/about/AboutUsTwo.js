import React from 'react';
import Video from './Video';
import NumberCounter from './NumberCounter'
import Datas from '../../data/about/about-us-two.json';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Styles } from "./styles/aboutUsTwo.js";

class AboutUsTwo extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        return (
            <Styles>
                {/* About Us Area */}
                <section className="about-us2-area">
                    <Container>
                        <Row>
                            <Col lg="5" md="0">
                                <div className="about-images">
                                    <img className="about-img3 img-fluid" src={process.env.PUBLIC_URL + `/assets/images/${this.state.Data.aboutImageThree}`} alt="" />
                                </div>
                            </Col>
                            <Col lg="7" md="12">
                                <div className="about-content">
                                    <div className="about-title">
                                        <p>{this.state.Data.secTitle}</p>
                                    </div>
                                    <div className="about-subtitle">
                                        <h3>{this.state.Data.secSubtitle}</h3>
                                    </div>
                                    <div className="about-desc">
                                        <p>{this.state.Data.secDesc}</p>
                                    </div>
                                    <div className="about-iconbox">
                                        <Row>
                                            <Col md="8">
                                                <h6>{this.state.Data.iconHeading}</h6>
                                                <ul className="icon-box list-unstyled">
                                                    <li><i className="las la-check-circle"></i>Lorem, ipsum dolor sit amet consectet minixe dimare tana.</li>
                                                    <li><i className="las la-check-circle"></i>Obcaecati makam kisim maxime lopu namkin vitae tempora.</li>
                                                    <li><i className="las la-check-circle"></i>Quidem totam quas consec nostrum sapan iksim ipsa soqu.</li>
                                                </ul>
                                                <Link className="rmore-btn" to={process.env.PUBLIC_URL + "/"}>Learn More</Link>
                                            </Col>
                                            <Col md="4">
                                                <Video />
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                            </Col>
                            <Col md="12">
                                <NumberCounter />
                            </Col>
                        </Row>
                    </Container>
                </section>
            </Styles>
        )
    }
}

export default AboutUsTwo