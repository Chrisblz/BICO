import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import BackToTop from '../common/BackToTop.js';
import { Styles } from "./styles/footer.js";

const Footer = () => {
    return (
        <Styles>
            {/* Footer Area */}
            <footer className="footer">
                <Container>
                    <Row>
                        <Col md="12">
                            <div className="footer-top">
                                <Row>
                                    <Col lg="3" md="0">
                                        <div className="logo">
                                            <Link to={process.env.PUBLIC_URL + "/"}><img src={process.env.PUBLIC_URL + "/assets/images/f-logo.png"} alt="" /></Link>
                                        </div>
                                    </Col>
                                    <Col md="6" sm="7">
                                        <div className="registration">
                                            <form action="#">
                                                <input type="text" placeholder="Enter email address" />
                                                <button type="submit">Subscribe</button>
                                            </form>
                                        </div>
                                    </Col>
                                    <Col lg="3" md="6" sm="5">
                                        <div className="social text-right">
                                            <ul className="list-unstyled list-inline">
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-facebook-f"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-twitter"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-linkedin-in"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-instagram"></i></a></li>
                                                <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fab fa-dribbble"></i></a></li>
                                            </ul>
                                        </div>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                        <Col md="12">
                            <div className="footr-main">
                                <Row>
                                    <Col lg="3" md="6">
                                        <div className="ft-about">
                                            <h5>About Us</h5>
                                            <p>Lorem ipsum dolor sit amet, consect adipisicing elit. Saepe porro neque a nam null quos.</p>
                                            <ul className="list-unstyled">
                                                <li><i className="las la-map-marker"></i>795 South Park Avenue, CA 94107.</li>
                                                <li><i className="las la-envelope"></i>enquery@domain.com</li>
                                                <li><i className="las la-phone"></i>+1 908 875 7678</li>
                                            </ul>
                                        </div>
                                    </Col>
                                    <Col lg="3" md="6">
                                        <div className="ft-link">
                                            <h5>Quick Links</h5>
                                            <ul className="list-unstyled">
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>General Info</Link></li>
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>Help Center</Link></li>
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>Our Services</Link></li>
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>Privacy Policy</Link></li>
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>Online Support</Link></li>
                                                <li><Link to={process.env.PUBLIC_URL + "/"}><i className="las la-angle-right"></i>Live Chat</Link></li>
                                            </ul>
                                        </div>
                                    </Col>
                                    <Col lg="3" md="6">
                                        <div className="ft-post">
                                            <h5>Latest News</h5>
                                            <div className="post-box d-flex">
                                                <div className="post-img">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/f-post-1.jpg"} alt="" className="img-fluid" />
                                                </div>
                                                <div className="post-content">
                                                    <span>Mar 21, 2021</span>
                                                    <Link to={process.env.PUBLIC_URL + "/blog-details"}>Lorem ipsum dolor sit amet consecte...</Link>
                                                </div>
                                            </div>
                                            <div className="post-box d-flex">
                                                <div className="post-img">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/f-post-2.jpg"} alt="" className="img-fluid" />
                                                </div>
                                                <div className="post-content">
                                                    <span>Mar 22, 2021</span>
                                                    <Link to={process.env.PUBLIC_URL + "/blog-details"}>Lorem ipsum dolor sit amet consecte...</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col lg="3" md="6">
                                        <div className="ft-gallery">
                                            <h5>Instagram</h5>
                                            <div className="gallery-box clearfix">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-3.jpg"} alt="" className="img-fluid" />
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-4.jpg"} alt="" className="img-fluid" />
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-5.jpg"} alt="" className="img-fluid" />
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-6.jpg"} alt="" className="img-fluid" />
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-7.jpg"} alt="" className="img-fluid" />
                                                <img src={process.env.PUBLIC_URL + "/assets/images/f-post-8.jpg"} alt="" className="img-fluid" />
                                            </div>
                                        </div>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                        <Col md="12">
                            <div className="copyright-area">
                                <Row>
                                    <Col md="6">
                                        <div className="copy-text">
                                            <p>Copyright &copy; 2021 | Designed With <i className="las la-heart"></i> by <a href={process.env.PUBLIC_URL + "/"} target="_blank" rel="noreferrer">SnazzyTheme</a></p>
                                        </div>
                                    </Col>
                                    <Col md="6" className="text-right">
                                        <ul className="copy-menu list-unstyled list-inline">
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}>Terms & Condition</a>|</li>
                                            <li className="list-inline-item"><a href={process.env.PUBLIC_URL + "/"}>Privacy Policy</a></li>
                                        </ul>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                    </Row>
                </Container>

                {/* Back To Top */}
                <BackToTop scrollStepInPx="50" delayInMs="10" />
            </footer>
        </Styles >
    )
}

export default Footer