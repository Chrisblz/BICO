import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .project2-area {
        padding : 65px 0;

        .project-slider {
            .slick-slider {
                .slick-slide {
                    padding: 0 15px;
                    .slider-item {
                        background: #fff;
                        transition: 1s ease all;
                        box-sizing: border-box;
                        border-radius: 20px;
                        overflow: hidden;
                        position: relative;
                        img{
                            max-width:100%; 
                            height: auto;
                            transition: all 0.3s ease 0s;
                        }

                        .filter-content {
                            position: absolute;
                            bottom : 0;
                            left : 0;
                            width: 100%;
                            height: auto;
                            padding: 20px 25px;
                            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.32) 85%);
                            transition: all 0.3s ease 0s;
                            p.pro-group {
                                color: #ffffff;
                                font-weight: 500;
                            }
                            h6.pro-title {
                                a {
                                    font-size : 16px;
                                    color : #ffffff;
                                    text-transform: uppercase;
                                    &:hover {
                                        color : ${colors.red};
                                    }
                                }
                            }
                        }

                        &:hover {
                            img {
                                transform: scale(1.1);
                            }
                            .filter-content {
                                padding-left : 40px;
                            }
                        }

                        &:focus {
                            outline: none;
                        }
                    }
                }
            }
        }

        @media only screen and (max-width: 575px) {
            padding: 35px 0 40px;
        }
    }
`;