import styled from "styled-components";
import { colors } from "../../common/element/elements.js";

export const Styles = styled.div`
    .project-area {
        padding : 205px 0 55px;

        .filter-btns {
            margin-bottom : 40px;
            button.filter-btn {
                font-size: 15px;
                color: ${colors.text2};
                padding : 8px 20px;
                font-weight: 500;
                cursor : pointer;
                border-radius: 0 22px;
                border: none;
                background: transparent;
                &:hover,
                &:active,
                &:focus {
                    color: #ffffff;
                    background: ${colors.red};
                }

                @media only screen and (max-width: 575px) {
                    font-size: 14px;
                    padding: 6px 17px;
                }
            }
        }

        .filter-items {
            column-count: 3;
            column-gap: 18px;
            .filter-item {
                display: inline-block;
                background: #fff;
                width: 100%;
                transition: 1s ease all;
                box-sizing: border-box;
                border-radius: 20px;
                overflow: hidden;
                margin-bottom: 15px;
                position: relative;
                img{
                    max-width:100%; 
                    height: auto;
                    transition: all 0.3s ease 0s;
                }

                .filter-content {
                    position: absolute;
                    bottom : 0;
                    left : 0;
                    width: 100%;
                    height: auto;
                    padding: 20px 25px;
                    background: linear-gradient(to bottom, rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.32) 85%);
                    transition: all 0.3s ease 0s;
                    p.pro-group {
                        color: #ffffff;
                        font-weight: 500;
                    }
                    h6.pro-title {
                        a {
                            font-size : 16px;
                            color : #ffffff;
                            text-transform: uppercase;
                            &:hover {
                                color : ${colors.red};
                            }
                        }
                    }
                }

                &:hover {
                    img {
                        transform: scale(1.1);
                    }
                    .filter-content {
                        padding-left : 40px;
                    }
                }
            }

            @media only screen and (max-width: 767px) {
                column-count: 2;
            }

            @media only screen and (max-width: 480px) {
                column-count: 1;
            }
        }

        @media only screen and (max-width: 991px) {
            padding: 165px 0 55px;
        }

        @media only screen and (max-width: 767px) {
            padding: 200px 0 55px;
        }

        @media only screen and (max-width: 575px) {
            padding: 185px 0 25px;
        }
    }
`;