import React from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/project/slider.json';
import { Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import { Styles } from "./styles/projectTwo.js";

class ProjectTwo extends React.Component {
    state = {
        Data: Datas
    }

    render() {
        const settings = {
            dots: false,
            arrows: false,
            infinite: true,
            slidesToShow: 4,
            autoplay: true,
            speed: 1500,
            autoplaySpeed: 5000,
            className: "center",
            centerMode: true,
            cssEase: "linear",
            pauseOnHover: true,
            responsive: [
                {
                    breakpoint: 1199,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                    }
                },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1,
                    }
                }
            ]
        };

        return (
            <Styles>
                {/* Project Area */}
                <section className="project2-area">
                    <Row className="margin-fix">
                        <Col md="12" className="padding-fix">
                            <SecTitle
                                title={this.state.Data.secTitle}
                                subTitle={this.state.Data.secHeading}
                            />
                        </Col>
                        <Col md="12" className="padding-fix">
                            <div className="project-slider">
                                <Slider {...settings}>
                                    {
                                        this.state.Data.dataList.map((data, i) => (
                                            <div className="slider-item" key={i}>
                                                <img src={process.env.PUBLIC_URL + `/assets/images/${data.imgUrl}`} alt="" className="img-fluid" />
                                                <div className="filter-content">
                                                    <p className="pro-group">{data.proGroup}</p>
                                                    <h6 className="pro-title"><Link to={process.env.PUBLIC_URL + data.proLink}>{data.proTitle}</Link></h6>
                                                </div>
                                            </div>
                                        ))
                                    }
                                </Slider>
                            </div>
                        </Col>
                    </Row>
                </section>
            </Styles>
        )
    }
}

export default ProjectTwo