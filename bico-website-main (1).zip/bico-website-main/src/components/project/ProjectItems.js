import React from 'react';
import { Link } from 'react-router-dom';

function ProjectItems({ menuItem }) {
    return (
        <div className="filter-items masonry">
            {
                menuItem.map((item) => {
                    return <div className="filter-item-box" key={item.id}>
                        <div className="filter-item" key={item.id}>
                            <img src={process.env.PUBLIC_URL + `/assets/images/${item.imgUrl}`} alt="" className="img-fluid" />
                            <div className="filter-content">
                                <p className="pro-group">{item.proGroup}</p>
                                <h6 className="pro-title"><Link to={process.env.PUBLIC_URL + item.proLink}>{item.proTitle}</Link></h6>
                            </div>
                        </div>
                    </div>
                })
            }
        </div>
    )
}

export default ProjectItems;