import React, { useState } from 'react';
import { SecTitle } from './../common/SecTitle';
import Datas from '../../data/project/filter.json';
import ProjectItems from './ProjectItems';
import ProjectCategories from './ProjectCategories';
import { Container, Row, Col } from 'react-bootstrap';
import { Styles } from "./styles/project.js";

const allCategories = ['All', ...new Set(Datas.dataList.map(item => item.category))];

const Project = () => {
    const [categories] = useState(allCategories);
    const [menuItems, setMenuItems] = useState(Datas.dataList);

    const filter = (category) => {
        if (category === 'All') {
            setMenuItems(Datas.dataList)
            return;
        }
        const filteredData = Datas.dataList.filter((item) => {
            return item.category === category;
        })
        setMenuItems(filteredData);
    }

    return (
        <Styles>
            {/* Project Area */}
            <section className="project-area">
                <Container>
                    <Row>
                        <Col md="12">
                            <SecTitle
                                title={Datas.secTitle}
                                subTitle={Datas.secHeading}
                            />
                        </Col>
                        <Col md="12">
                            <div className="project-box">
                                <ProjectCategories filter={filter} categories={categories} />
                                <ProjectItems menuItem={menuItems} />
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </Styles>
    )
}

export default Project;