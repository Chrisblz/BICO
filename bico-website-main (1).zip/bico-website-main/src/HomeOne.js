import React from 'react';
import PreLoader from './components/common/PreLoader';
import Header from './components/header/Header';
import HeroImage from './components/hero-image/HeroImage';
import AboutUs from './components/about/AboutUs';
import Service from './components/service/Service';
import Banner from './components/banner/Banner';
import Project from './components/project/Project';
import TeamSlider from './components/team/TeamSlider';
import CustomerCare from './components/customer-care/CustomerCare';
import Faq from './components/faq/Faq';
import Pricing from './components/pricing/Pricing';
import TestimonialSlider from './components/testimonial/TestimonialSlider';
import HomeBlog from './components/blog/HomeBlog';
import Brand from './components/brand/Brand';
import Footer from './components/footer/Footer';

const HomeOne = () => {
    return (
        <div className="main-wrapper" >

            {/* Pre Loader */}
            <PreLoader />

            {/* Header */}
            <Header />

            {/* Hero Image */}
            <HeroImage />

            {/* About Us */}
            <AboutUs />

            {/* Service Area */}
            <Service />

            {/* Banner Area */}
            <Banner />

            {/* Project Area */}
            <Project />

            {/* Team Area */}
            <TeamSlider />

            {/* Customer Care */}
            <CustomerCare />

            {/* Faq Area */}
            <Faq />

            {/* Pricing Area */}
            <Pricing />

            {/* Testimonial Area */}
            <TestimonialSlider />

            {/* Blog Area */}
            <HomeBlog />

            {/* Brand Area */}
            <Brand />

            {/* Footer Area */}
            <Footer />

        </div>
    )
}

export default HomeOne
