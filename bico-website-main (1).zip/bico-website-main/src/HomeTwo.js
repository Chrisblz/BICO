import React from 'react';
import HeaderTwo from './components/header/HeaderTwo';
import HeroSlider from './components/hero-slider/HeroSlider';
import IconBox from './components/icon-box/IconBox';
import AboutUsTwo from './components/about/AboutUsTwo';
import ServiceTwo from './components/service/ServiceTwo';
import WhyUs from './components/why-us/WhyUs';
import ProjectTwo from './components/project/ProjectTwo';
import TeamSlider from './components/team/TeamSlider';
import CustomerCare from './components/customer-care/CustomerCare';
import Consultation from './components/consultation/Consultation';
import Pricing from './components/pricing/Pricing';
import TestimonialSlider from './components/testimonial/TestimonialSlider';
import HomeBlog from './components/blog/HomeBlog';
import Brand from './components/brand/Brand';
import Footer from './components/footer/Footer';

const HomeTwo = () => {
    return (
        <div className="main-wrapper" >

            {/* Header 2 */}
            <HeaderTwo />

            {/* Hero Slider */}
            <HeroSlider />

            {/* Icon Box */}
            <IconBox />

            {/* About Us */}
            <AboutUsTwo />

            {/* Service Area */}
            <ServiceTwo />

            {/* Why Us Area */}
            <WhyUs />

            {/* Project Area */}
            <ProjectTwo />

            {/* Team Area */}
            <TeamSlider />

            {/* Help Area */}
            <CustomerCare />

            {/* Consultation Area */}
            <Consultation />

            {/* Pricing Area */}
            <Pricing />

            {/* Testimonial Area */}
            <TestimonialSlider />

            {/* Blog Area */}
            <HomeBlog />

            {/* Brand Area */}
            <Brand />

            {/* Footer Area */}
            <Footer />

        </div>
    )
}

export default HomeTwo
