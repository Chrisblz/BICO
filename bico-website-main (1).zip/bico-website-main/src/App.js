import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import ScrollToTop from './helper/ScrollToTop';
import { GlobalStyle } from "./components/common/styles/global.js";
import 'bootstrap/dist/css/bootstrap.min.css';
import HomeOne from './HomeOne';
import HomeTwo from './HomeTwo';
import About from './pages/about/About';
import ServiceStyleOne from './pages/service/ServiceStyleOne';
import ServiceStyleTwo from './pages/service/ServiceStyleTwo';
import ServiceDetails from './pages/service/ServiceDetails';
import ProjectStyleOne from './pages/project/ProjectStyleOne';
import ProjectStyleTwo from './pages/project/ProjectStyleTwo';
import ProjectDetails from './pages/project/ProjectDetails';
import BlogGrid from './pages/blog/BlogGrid';
import BlogClassic from './pages/blog/BlogClassic';
import BlogDetails from './pages/blog/BlogDetails';
import Contact from "./pages/contact/Contact.js";
import Appointment from "./pages/appointment/Appointment.js";
import Question from "./pages/faq/Questions.js";
import Error from "./pages/error/Error.js";
import ComingSoon from './pages/coming-soon/ComingSoon';

function App() {
    return (
        <Router>
            <GlobalStyle />
            <ScrollToTop />
            <Switch>
                <Route exact path={`${process.env.PUBLIC_URL + "/"}`} component={HomeOne} />
                <Route path={`${process.env.PUBLIC_URL + "/home-two"}`} component={HomeTwo} />
                <Route path={`${process.env.PUBLIC_URL + "/about"}`} component={About} />
                <Route path={`${process.env.PUBLIC_URL + "/service-one"}`} component={ServiceStyleOne} />
                <Route path={`${process.env.PUBLIC_URL + "/service-two"}`} component={ServiceStyleTwo} />
                <Route path={`${process.env.PUBLIC_URL + "/service-details"}`} component={ServiceDetails} />
                <Route path={`${process.env.PUBLIC_URL + "/project-one"}`} component={ProjectStyleOne} />
                <Route path={`${process.env.PUBLIC_URL + "/project-two"}`} component={ProjectStyleTwo} />
                <Route path={`${process.env.PUBLIC_URL + "/project-details"}`} component={ProjectDetails} />
                <Route path={`${process.env.PUBLIC_URL + "/blog-grid"}`} component={BlogGrid} />
                <Route path={`${process.env.PUBLIC_URL + "/blog-classic"}`} component={BlogClassic} />
                <Route path={`${process.env.PUBLIC_URL + "/blog-details"}`} component={BlogDetails} />
                <Route path={`${process.env.PUBLIC_URL + "/contact"}`} component={Contact} />
                <Route path={`${process.env.PUBLIC_URL + "/appointment"}`} component={Appointment} />
                <Route path={`${process.env.PUBLIC_URL + "/faq"}`} component={Question} />
                <Route path={`${process.env.PUBLIC_URL + "/error"}`} component={Error} />
                <Route path={`${process.env.PUBLIC_URL + "/coming-soon"}`} component={ComingSoon} />
            </Switch>
        </Router>
    )
}

export default App;
